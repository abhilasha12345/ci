<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Superadmin extends CI_Controller {

	public function __construct()

	{
	    parent::__construct();
	  	$this->load->model('superadmin_model');
	}

	private function _check_login(){
		if(superadmin_logged_in()===FALSE)
			redirect('superadmin/login');
	}

	private function salt() {
		return substr(md5(uniqid(rand(), true)), 0, 10);
	}

	public function pdf_image(){
		$this->load->library('M_pdf');	
		$data['list'] ='demo';
		$html= $this->load->view('school/pdf_image',$data,true);
		$pdfFilePath = "test.pdf";
		$this->m_pdf->pdf->WriteHTML($html);
		$this->m_pdf->pdf->Output($pdfFilePath, "I"); 
	}


	public function check_image($str){

    	$this->_check_login(); //check login authentication

		if(empty($_FILES['school_logo']['name'])){

				$this->form_validation->set_message('check_image', 'Choose Image');

			   return FALSE;

			}

		

		if(!empty($_FILES['school_logo']['name'])):
			$config['upload_path']   = './assets/uploads/school';
			$config['allowed_types'] = 'jpg|png|jpeg';
			$config['max_width']     = '1600';
			$config['max_height']    = '1200';
			$config['min_width']     = '350';
			$config['min_height']    = '150';
			$config['file_name']     = $this->salt();
			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('school_logo')){

				$this->form_validation->set_message('check_image', $this->upload->display_errors());

				return FALSE;

			}else{

					$fileData = $this->upload->data(); // upload image  

				    $config_imgp['source_path']      = './assets/uploads/school/';

	                $config_imgp['destination_path'] = './assets/uploads/school/thumbnail/';

	                $config_imgp['width']            = '450';

	                $config_imgp['height']           = '250';

	                $fileData = $this->upload->data();

	              	$config_imgp['file_name']        = $fileData['file_name'];

	                $status          = create_thumbnail($config_imgp);

	                   

				$this->session->set_userdata('check_image',array('image_url'=>$config['upload_path'].$fileData['file_name'],

					 'image'=>$fileData['file_name']));

				return TRUE;

			}

		else:

			$this->form_validation->set_message('check_image', 'The %s field required');

			return FALSE;

		endif;

    }



	public function index()

	{   

		$this->session->unset_userdata('student_reprot_data');

		$this->form_validation->set_rules('student_id', 'student_id', 'trim|required');

		$this->form_validation->set_rules('parent_mobile', 'Please enter valid Mobile No.', 'required|callback__check_phone');

		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if($this->form_validation->run() == TRUE){

			$student_id = $this->input->post('student_id');

       		$parent_mobile = $this->input->post('parent_mobile');

       		$student =	explode('-',$student_id);

       		if(!empty($student[0]) && !empty($student[1])){

				$student_info= $this->common_model->get_row('student', array('school_prefix'=>$student[0],'unique_id'=>$student[1],'parent_mobile'=>$parent_mobile));

			

				if(!empty($student_info)){

					$test_student= $this->common_model->get_row('student_test', array('student_id'=>$student_info->student_id));



			        if(!empty($test_student)){

			        	$data['otp']=rand(1000, 9999);

			        	$data['student_id']=$student_id;

			        	$data['parent_mobile']=$parent_mobile;	

						$data['student_info'] = $student_info;

					    $data['school_info'] = school_info($data['student_info']->school_id);

					    $class_name = $this->common_model->get_row('class',array('id'=>$student_info->class));

                       



                       if(!empty($class_name))

                        $data['class_name']=$class_name->class_name;

                        else 

                          $data['class_name']='';

					 //    $message="Dear Customer,

						// ".$data['otp']." is your one time password.

						// Thank you";

					 //    sms($message,$parent_mobile);

					 //    $this->session->set_userdata('student_reprot_data',$data);

						// redirect('superadmin/otp');	
                     // p($data);die;
                      


                      	 $data['tests'] = $this->superadmin_model->find_testnames_by_student_id($student_info->student_id);
                           
					 $this->load->view('superadmin/student_report',$data); 

			     	}else{



			  		$this->session->set_flashdata('msg_error','Sorry! Student report not available, Please contact admin.');

			  		redirect(base_url());

			  		}



				    	

		  		}else{



		  		$this->session->set_flashdata('msg_error','Sorry! Student record not available, Please try again.');

		  		redirect(base_url());

		  		}



	  		}else{



	  		$this->session->set_flashdata('msg_error','Sorry! Your student id invalid, Please try again.');

	  		redirect(base_url());

	  		}

			

  		} else {

  			$this->load->view('superadmin/index'); 

  		}

	}

	public function otp()

	{

 		$data=$this->session->userdata('student_reprot_data');	

 		if(empty($data)){

 			$this->session->set_flashdata('msg_error','Sorry! Your student id invalid, Please try again.');

	  		redirect(base_url());

	  	}

	  	if(isset($_POST['otp']) && $_POST['otp']==$data['otp'])

	  		redirect('superadmin/student_report');

	  	elseif(isset($_POST['otp']) && $_POST['otp']!=$data['otp']){

	  		$this->session->set_flashdata('msg_error','Sorry! Your student id invalid, Please try again.');

	  		redirect('superadmin/otp');

	  	}

		$this->load->view('superadmin/opt',$data);

	}

	function student_report()

	{ 
  
		$data=$this->session->userdata('student_reprot_data');


		if(empty($data)){

 			$this->session->set_flashdata('msg_error','Sorry! Your student id invalid, Please try again.');

	  		redirect(base_url());

	  	}	

		$this->load->view('superadmin/student_report',$data); 

	}

	public function report($student_id,$view='I')
	{   
	     $this->load->library('M_pdf');	
	    $test_id=$this->input->get('test_id');
        $data['student']     = $this->common_model->get_row('student',array('student_id'=>$student_id));
        if(empty($data['student']))
        {
            $this->session->set_flashdata('msg_error','Sorry! Your student id invalid, Please try again.');

	  		redirect($_SERVER['HTTP_REFERER']);
        }
        if(empty($test_id))
        {
            $this->session->set_flashdata('msg_error','Sorry! Test Id is empty.');

	  		redirect('superadmin/not_found');
        }

    	$data['school_info'] = school_info($data['student']->school_id);
    	//$class_name          = $this->common_model->get_row('class',array('id'=>$data['student']->class));
        //$data['class_name']=$class_name->class_name;

		$school_id=$data['student']->school_id;

        if (empty($data['student']))
        {
            redirect('school/students');
        }

    	$test_student= $this->common_model->get_row('student_test', array('student_id'=>$student_id,'test_id'=>$test_id));


        if(!empty($test_student)){
     		$data['general'] 			 = json_decode($test_student->general);
     		$data['eye'] 				 = json_decode($test_student->eye);
			$data['dental'] 			 = json_decode($test_student->dental);
     		$data['ent'] 				 = json_decode($test_student->ent);
     		$data['cardiovascular'] 	 = json_decode($test_student->cardiovascular);
     		$data['examination'] 		 = json_decode($test_student->examination);
     		$data['upload_file'] 		 = json_decode($test_student->upload_file);
     		$data['general_per'] 		 = $test_student->general_per;
     		$data['eye_per'] 			 = $test_student->eye_per;
     		$data['dental_per'] 		 = $test_student->dental_per;
     		$data['final_notes'] 		 = $test_student->final_notes;
     		$data['ent_per'] 			 = $test_student->ent_per;
     		$data['cardiovascular_per']  = $test_student->cardiovascular_per;
     		$data['examination_per'] 	 = $test_student->examination_per;
     		$data['scal'] 				 = json_decode($test_student->scal);
			$data['created'] 			 = $test_student->created;
			$data['examinationswitch']   = $test_student->examinationswitch;
     		$data['eyeswitch']			 = $test_student->eyeswitch;
     		$data['generalswitch']		 = $test_student->generalswitch;
     		$data['dentalswitch']		 = $test_student->dentalswitch;
     		$data['entswitch']			 = $test_student->entswitch;
     		$data['cardiovascularswitch']= $test_student->cardiovascularswitch;						
			$data['general_notes']         = $test_student->general_notes;			
			$data['eye_notes']             = $test_student->eye_notes;			
			$data['dental_notes']          = $test_student->dental_notes;			
			$data['ent_notes']             = $test_student->ent_notes;			
			$data['cardiovascular_notes']  = $test_student->cardiovascular_notes;			
			$data['examination_notes']     = $test_student->examination_notes;	


           if(!empty($test_student->class_id))$data['student']->class=$test_student->class_id;               
           if(!empty($test_student->division))$data['student']->division=$test_student->division;          
           if(!empty($test_student->roll_no))$data['student']->roll_no=$test_student->roll_no;  
           $data['class_name']=class_name($data['student']->class);                                    
                       
     	}
     	
        $html= $this->load->view('school/test_report',$data,true);
		$pdfFilePath = "test.pdf";
		$this->m_pdf->pdf->WriteHTML($html);
		// $pdfFilePath = "test.pdf";

		//$this->m_pdf->pdf->WriteHTML($html);

//download it D save F.
if($view=='I')
  		$this->m_pdf->pdf->Output($pdfFilePath, "I");   
else
$this->m_pdf->pdf->Output($pdfFilePath, "D");   
	}





	public function school_report($view='pdf')

	{   

	$this->load->library('M_pdf');

	

	$data['created'] = 'demo';

		if($view == "pdf"){

			 $html= $this->load->view('school/school_report',$data,true);



			$pdfFilePath = "test.pdf";

			$this->m_pdf->pdf->WriteHTML($html);

			$this->m_pdf->pdf->Output($pdfFilePath, 'I');

		}else{

			$this->load->view('school/school_report',$data);

		}

	}

		

	



public function dashboard()

{  	

	$this->_check_login();

	$data['title']='Dashboard';

 	$data['template']='superadmin/dashboard';

    $data['student_no']=$this->superadmin_model->count_student();

   	$data['dr_no']=$this->superadmin_model->count_dr();



	$data['school_no']=$this->superadmin_model->count_school();

	$data['top_student']=$this->superadmin_model->top_student();

	$data['dr_active']=$this->superadmin_model->check_status('2','1','dr_active');

	$data['dr_inactive']=$this->superadmin_model->check_status('2','0','dr_inactive');

	$data['school_active']=$this->superadmin_model->check_status('3','1','school_active');

	$data['school_inactive']=$this->superadmin_model->check_status('3','0','school_inactive');

  $data['total_completereport']=count($this->superadmin_model->total_completereport());

  $data['total_uncompletereport']=count($this->superadmin_model->total_uncompletereport());

  $data['school']=$this->common_model->get_result('users',array('user_role' =>3),array('full_name','user_id','email','status','mobile','location'),array('user_id','DESC'),'5,0');

  $data['dr']=$this->common_model->get_result('users',array('user_role' =>2),array('full_name','user_id','email','status','mobile','location','specialist'),array('user_id','DESC'),'5,0');

  $data['student_active']=$this->superadmin_model->check_status_school('1','student_active');

	$data['student_inactive']=$this->superadmin_model->check_status_school('0','student_inactive');

	 $data['dr_dentist']=$this->superadmin_model->get_specility('2','dentist','Dentist');

	$data['dr_physician']=$this->superadmin_model->get_specility('2','physician','Physician');

	$data['dr_optometrist']=$this->superadmin_model->get_specility('2','optometrist','Optometrist');

	$data['dr_super_specialist']=$this->superadmin_model->get_specility('2','super_specialist','Super Specialist');

	$data['dr_technician']=$this->superadmin_model->get_specility('2','technician','Technician');

    $this->load->view('templates/superadmin/superadmin_template',$data);

	}

	

	public function login(){

		 if(superadmin_logged_in()===TRUE) redirect('superadmin/dashboard');

		 if(doctor_logged_in()===TRUE) redirect('doctor/dashboard');

		 if(school_logged_in()===TRUE) redirect('school/students');	

		 $data['title']='Admin login';

		  $this->form_validation->set_rules('password', 'Password', 'trim|required');

		  $this->form_validation->set_rules('email', 'Email', 'required');

		  $this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if($this->form_validation->run() == TRUE){

			$email = $this->input->post('email');

       		$password = $this->input->post('password');

			if($this->common_model->login($email,$password)){

			if(superadmin_logged_in()===TRUE) redirect('superadmin/dashboard');

			if(doctor_logged_in()===TRUE) redirect('doctor/dashboard');

			if(school_logged_in()===TRUE) redirect('school/students');	

			}else{

				redirect('superadmin/login');

			}

		}

		

		$this->load->view('superadmin/login');

	}



	

	public function logout(){

		$this->_check_login(); //check  login authentication

		$this->session->sess_destroy();

		redirect(site_url().'superadmin/login');

	}



	public function profile(){

		$this->_check_login();

		$data['title']='Profile';

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check['.superadmin_id().']');

		$this->form_validation->set_rules('full_name', 'Full name', 'required|callback_alpha_dash_space');

    	$this->form_validation->set_rules('mobile', 'Please enter valid Mobile No.', 'trim|required|callback__check_phone');

		$this->form_validation->set_rules('zip', 'ZIP code', 'trim|min_length[4]|max_length[8]');

		$this->form_validation->set_rules('location', 'Location', 'trim');



		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$user_data  = array(

				

				'full_name'	=>	$this->input->post('full_name'),

				'email'			=>	$this->input->post('email'),

				'mobile'		=>	$this->input->post('mobile'),

				'location'		=>	$this->input->post('location'),

				'modified' => date('Y-m-d H:i:s')

			);

			if($this->common_model->update('users', $user_data,array('user_id'=>superadmin_id()))){

				 $this->session->set_flashdata('msg_success','Your account details updated successfully.');

				redirect('superadmin/profile');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Your account details updation process failed, Please try again.');

				redirect('superadmin/profile');

			}

		}



		$data['user'] = $this->common_model->get_row('users', array('user_id'=>superadmin_id()));

 		$data['template']='superadmin/profile';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}





	function email_check($str='',$id=''){

   $LIST =$this->common_model->get_row('users',array('email'=>$str,'user_id !='=>$id));

		if(!empty($LIST->email)):

			$this->form_validation->set_message('email_check', 'The %s address already exists.');

		   return FALSE;

		else:

		   return TRUE;

		endif;

	}



	function code_check($str='',$id=''){



		if($this->common_model->get_row('users',array('code'=>$str,'user_id !='=>$id))):

			$this->form_validation->set_message('code_check', 'The %s already exists.');

		   return FALSE;

		else:

		   return TRUE;

		endif;

	}



	function prefix_check($str='',$id=''){

		if($this->common_model->get_row('school',array('unique_prefix'=>$str,'user_id !='=>$id))):

			$this->form_validation->set_message('prefix_check', 'The %s already exists.');

		   return FALSE;

		else:

		   return TRUE;

		endif;

	}



	public function forgotpassword()

	{

		if(superadmin_logged_in()===TRUE) redirect('superadmin/dashboard');

		if(doctor_logged_in()===TRUE) redirect('doctor/dashboard');

		if(school_logged_in()===TRUE) redirect('school/dashboard');	

		$data['title']='Forgot Password';



		$this->form_validation->set_rules('email', 'Email', 'trim|required');

    	$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

    	if ($this->form_validation->run() == TRUE){

    		$email = $this->input->post('email');

	    	$data  = array('email'=>$email);	

			$query_get = $this->db->get_where('users',$data);

			$count = $query_get->num_rows();

			$res = $query_get->row_array();

			if(empty($res))

			{

				$data  = array('code'=>$email);	

				$query_get = $this->db->get_where('users',$data);

				$count = $query_get->num_rows();

				$res = $query_get->row_array();

			}

    	

    		if(!empty($res)){

    			

    			if(!empty($res['email'])){

	                $new_password_key=trim(md5($res['email']));

	                $updateResult = $this->common_model->update('users',array('new_password_key'=>$new_password_key,'new_password_requested'=>date('Y-m-d H:i:s')),array('user_id'=>$res['user_id']));

	                if($updateResult){







	  //               	$email_template = $this->common_model->get_row('email_templates', array('id'=>1));



	  //   				if(!empty($email_template)){

								

			// $param1 	   = array(

			//     				  'site_name'       => 'Vigour',

			// 					  'name'            => ucwords($res['email']),

		 //                          'user_email'      => $res['email'],

			// 					  'activation_key'  =>'<a href="'.base_url().'page/reset_password/'.$new_password_key.'"><strong>'.base_url().'page/reset_password/'.$new_password_key.'</strong></a>',

			// 					  'contactus_link'  => base_url('page/contact')

			// 				);	    			 

    	

    		

   //  		$html = array();

	  //       $html['email_message'] = $email_template->template_body;

	  //       $html = $this->load->view('templates/email/email_template', $html, true);

	  //       $param = array(

	  //               'template'  =>  array(

	  //                           'temp'      => $html,

	  //                           'var_name'  => $param1, 

	  //                           ),            

	  //               'email' =>  array(

	  //                     'to'        =>    'sohit.chapter247@gmail.com',

	  //                     'from'      =>    'sohit.chapter247@gmail.com',

	  //                     'from_name' =>    'sohit.chapter247@gmail.com',

	  //                     'subject'   =>    $email_template->template_subject

	  //               )

	  //       );

	  //       p($this->chapter247_email->send_mail($param));die;

		    				
         



		                $msg_success='<p>Password reset instructions have been sent to <strong>'.$res['email'].'</strong>. Don\'t forget to check your spam and junk folders if it didn\'t show up.</p>';

		                $this->session->set_flashdata('msg_error',$msg_success);

		                redirect('superadmin/forgotpassword');



	                }

	            }else{              

                $this->session->set_flashdata('msg_error', 'Your email isn\'t available in our records. Please contact admin.');

                redirect('superadmin/forgotpassword');

           		}    

            }else{              

                $this->session->set_flashdata('msg_error', 'Your recode isn\'t available in our system.');

                redirect('superadmin/forgotpassword');

            }

    	}

	
	    $this->load->view('superadmin/forgotpassword',$data);



	}



	



	public function change_password(){

		$this->_check_login(); //check login authentication

		$data['title']='change_password';

		$this->form_validation->set_rules('oldpassword', 'Current Password', 'trim|required|callback_password_check');

		$this->form_validation->set_rules('newpassword', 'New Password', 'trim|required|matches[confpassword]');

		$this->form_validation->set_rules('confpassword','Confirm Password', 'trim|required');

		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE){

			$salt = $this->salt();

			$user_data  = array('salt'=>$salt,'password' => sha1($salt.sha1($salt.sha1($this->input->post('newpassword')))));

			if($this->common_model->update('users',$user_data,array('user_id'=>superadmin_id()))){

				$this->session->set_flashdata('msg_success','Password updated successfully.');

				redirect('superadmin/change_password');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Password updation process has been failed. Please try again.');

				redirect('superadmin/change_password');

			}

		}

		

		$data['template']='superadmin/change_password';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}





	public function password_check($oldpassword){

		$this->_check_login(); //check login authentication

		

		$user_info = $this->common_model->get_row('users',array('user_id'=>superadmin_id()));

        $salt = $user_info->salt;

		if($this->common_model->password_check(array('password'=>sha1($salt.sha1($salt.sha1($oldpassword)))),superadmin_id())){

			return TRUE;

		}else{

			$this->form_validation->set_message('password_check', 'The %s does not match');

			return FALSE;

		}



	}





	public function schools($offset=0){

		$offset=(int) $offset;

		if($offset < 0){

      		$this->session->set_flashdata('msg_error','Something went wrong! Please try again.'); 

      	redirect('superadmin/schools/');

      	}

		$this->_check_login();

		$data['title']='schools';

		$per_page=PER_PAGE;

		$data['schools'] = $this->superadmin_model->schools($offset,$per_page);

 		$config=backend_pagination();

		$config['base_url'] = base_url().'superadmin/schools/';

		$config['total_rows'] = $this->superadmin_model->schools(0,0);

		$config['per_page'] = $per_page;

		$config['uri_segment'] = 3;

		$config['reuse_query_string'] = TRUE;

		$data['offset']=$offset;

		if(!empty($_SERVER['QUERY_STRING'])){

			$config['suffix'] = "?".$_SERVER['QUERY_STRING'];

		}

		if($config['total_rows'] < $offset){

          

            if(!empty($_SERVER['QUERY_STRING'])){

			$suffix = "?".$_SERVER['QUERY_STRING'];

			}else{

			$suffix =''	;

			}  	 	

           redirect('superadmin/schools/'.$suffix);

    	}

    	$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();

 		$data['offset']=$offset;

        $i=0;
        foreach($data['schools'] as $sch){
            $tests =$this->common_model->get_result('test',array('school_id'=>$sch->user_id),'',array('test_id','DESC'));
            if(!empty($tests))$data['schools'][$i]->tests=$tests;
                else $data['schools'][$i]->tests=array();
            $i++;
        }
       

 		$data['template']='superadmin/schools';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}



	public function add_school(){

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['title']='Add school';

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');

		$this->form_validation->set_rules('unique_prefix', 'School Prefix', 'required|callback_prefix_check');

		$this->form_validation->set_rules('full_name', 'Full name', 'required|callback_alpha_dash_space');

    	$this->form_validation->set_rules('location', 'Location', 'trim|max_length[50]');

		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		$this->form_validation->set_rules('mobile[]', 'Please enter valid Mobile No.', 'trim|callback__check_phone');

		if(!empty($_FILES) && $_FILES['school_logo']['name']!='')

		$this->form_validation->set_rules('school_logo', '', 'callback_check_image');

		

		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$salt = $this->salt();



			$image ='';

			if($this->session->userdata('check_image')!=''):

                $check_logo_img=$this->session->userdata('check_image');

                $image = 'assets/uploads/school/thumbnail/'.$check_logo_img['image'];               

                $this->session->unset_userdata('check_image');

            endif;

			$user_data  = array();





			$user_data  = array(

				

				'full_name'		=>	$this->input->post('full_name'),

				'email'			=>	$this->input->post('email'),

				'user_role'		=>  3,

				'status'		=>  1,

				'salt'			=>	$salt,

				'password' 		=> sha1($salt.sha1($salt.sha1($this->input->post('password')))),

				'location'		=>	$this->input->post('location'),

				'created' => date('Y-m-d H:i:s')

			);

			if($school_id = $this->common_model->insert('users', $user_data)){

				if(!empty($this->input->post('doctor[]'))){

				$doctors = implode(",",$this->input->post('doctor'));

				$school_data  = array(

				'unique_prefix'		=>	$this->input->post('unique_prefix'),

				'user_id'			=>	$school_id,

				'doctors_id'		=>	$doctors,

				'school_logo'   =>	$image,

				);

				

				}else{

				$school_data  = array(

				'unique_prefix'		=>	$this->input->post('unique_prefix'),

				'user_id'			=>	$school_id,

				'school_logo'   =>	$image,

				);

				}

				$this->common_model->insert('school', $school_data);
				//echo $this->db->last_query();die;

				if(!empty($this->input->post('contact_name[]'))){

				$contact_name =	$this->input->post('contact_name[]');

				$mobile =	$this->input->post('mobile[]');

					foreach ($contact_name as $key => $value) {

						if(!empty($contact_name[$key]) || !empty($mobile[$key])){

						$this->common_model->delete('school_contact',array('school_id'=>$school_id,'contact_name'=>$contact_name[$key],'contact_mobile'	=>	$mobile[$key]));



							$school_contact  = array();

							$school_contact  = array(

								'contact_name'		=>	$contact_name[$key],

								'contact_mobile'	=>	$mobile[$key],

								'school_id'			=>	$school_id,

							);

							$this->common_model->insert('school_contact', $school_contact);

						}

					}

				}

			

				$this->session->set_flashdata('msg_success','Your schools details add successfully.');

				redirect('superadmin/schools');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Your schools details add process failed, Please try again');

				redirect('superadmin/schools');

			}

		

		}

		$data['doctor']=$this->common_model->get_result('users',array('user_role' =>2,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

		

 		$data['template']='superadmin/add_schools';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}





	public function edit_school($id=0){

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['title']='Edit School';

		$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));

		if(empty($data['user']))

			redirect('superadmin/schools');

		$data['school'] = $this->common_model->get_row('school',array('user_id'=>$id));

		//p($data);die;

        if (empty($data['user']))

        {

            redirect('superadmin/schools');

        }

        

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check['.$id.']');

		$this->form_validation->set_rules('unique_prefix', 'School Prefix', 'required|callback_prefix_check['.$id.']');

		$this->form_validation->set_rules('full_name', 'Full name', 'required|callback_alpha_dash_space');

    	$this->form_validation->set_rules('location', 'Location', 'trim|max_length[50]');

    	$this->form_validation->set_rules('mobile[]', 'Please enter valid Mobile No.', 'trim|callback__check_phone');

    	if(!empty($_FILES) && $_FILES['school_logo']['name']!='')

    	$this->form_validation->set_rules('school_logo', '','callback_check_image');


		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{



			$image =$this->input->post('old_school_logo');
            
            
			if($this->session->userdata('check_image')!='' ):
                $check_logo_img=$this->session->userdata('check_image');
                $image ='assets/uploads/school/thumbnail/'.$check_logo_img['image'];
                $this->session->unset_userdata('check_image');

            endif;
            

			

			if(!empty($this->input->post('password'))){

				$salt = $this->salt();

			$user_data  = array('salt'=>$salt,'password' => sha1($salt.sha1($salt.sha1($this->input->post('password')))));

			$this->common_model->update('users',$user_data,array('user_id'=>$id));

			}		

			

			$user_data  = array();

			$user_data  = array(
				'full_name'		=>	$this->input->post('full_name'),
				'email'			=>	$this->input->post('email'),
				'location'		=>	$this->input->post('location'),
				'modified'      => date('Y-m-d H:i:s')

			);



			if($this->common_model->update('users', $user_data,array('user_id'=>$id))){

				if(!empty($this->input->post('doctor[]'))){

				$doctors = implode(",",$this->input->post('doctor'));

				$school_data['unique_prefix'] = $this->input->post('unique_prefix');
				$school_data['doctors_id']    = $doctors;
				$school_data['school_logo']   = $image;

				}else{

				$school_data['unique_prefix'] = $this->input->post('unique_prefix');
				$school_data['school_logo']   = $image;
				
				}

				$this->common_model->update('student',array('school_prefix'=>$this->input->post('unique_prefix')),array('school_id'=>$id));

				$this->common_model->update('school', $school_data,array('user_id'=>$id));


				$this->common_model->delete('school_contact',array('school_id'=>$id));



				if(!empty($this->input->post('contact_name[]'))){

				$contact_name =	$this->input->post('contact_name[]');

				$mobile =	$this->input->post('mobile[]');

					foreach ($contact_name as $key => $value) {

						if(!empty($contact_name[$key]) || !empty($mobile[$key])){

							$this->common_model->delete('school_contact',array('school_id'=>$id,'contact_name'=>$contact_name[$key],'contact_mobile'	=>	$mobile[$key]));

							$school_contact  = array();

							$school_contact  = array(

								'contact_name'		=>	$contact_name[$key],

								'contact_mobile'	=>	$mobile[$key],

								'school_id'			=>	$id,

							);

							$this->common_model->insert('school_contact', $school_contact);

						}

					}

				}

				 $this->session->set_flashdata('msg_success','Your school details updated successfully.');

				redirect('superadmin/schools');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Your school details updation process failed, Please try again.');

				redirect('superadmin/schools');

			}

		

		}

		$data['doctor']=$this->common_model->get_result('users',array('user_role' =>2,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

	//	$data['school']=$this->common_model->get_result('users',array('user_role' =>3,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

		$data['template']='superadmin/edit_school';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}







	public function doctors($offset=0){

		$offset=(int) $offset;

		if($offset < 0){

      		$this->session->set_flashdata('msg_error','Something went wrong! Please try again.'); 

      	redirect('superadmin/doctors/');

      	}   

     	

		$this->_check_login();

		$data['title']='Doctors';

		$per_page=PER_PAGE;



		$data['doctors'] = $this->superadmin_model->doctors($offset,$per_page);

		$config=backend_pagination();

		$config['base_url'] = base_url().'superadmin/doctors/';

		$config['total_rows'] = $this->superadmin_model->doctors(0,0);

		$config['per_page'] = $per_page;

		$config['uri_segment'] = 3;

		$config['reuse_query_string'] = TRUE;

		if(!empty($_SERVER['QUERY_STRING'])){

			$config['suffix'] = "?".$_SERVER['QUERY_STRING'];

		}

		if($config['total_rows'] < $offset){

          

           if(!empty($_SERVER['QUERY_STRING'])){

			$suffix = "?".$_SERVER['QUERY_STRING'];

			}else{

			$suffix =''	;

			}  	

           redirect('superadmin/doctors/'.$suffix);

    	}

		$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();

 		$data['offset']=$offset;

		

 		$data['template']='superadmin/doctors';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}



	





	public function add_doctor(){

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['title']='Add Doctor';

		$this->form_validation->set_rules('email', 'Email', 'valid_email|callback_email_check');

		$this->form_validation->set_rules('full_name', 'Doctor name', 'required|callback_alpha_dash_space');

		$this->form_validation->set_rules('code', 'Doctor Code', 'required|callback_code_check');

		$this->form_validation->set_rules('specialist', 'Doctor specialist', 'required');

    	$this->form_validation->set_rules('mobile', 'Please enter valid Mobile No.', 'trim|callback__check_phone');

		$this->form_validation->set_rules('location', 'Location', 'trim');

		$this->form_validation->set_rules('password', 'Password', 'trim|required');

	



		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$salt = $this->salt();

			$user_data  = array();

			$user_data  = array(

				

				'full_name'		=>	$this->input->post('full_name'),

				'email'			=>	$this->input->post('email'),

				'mobile'		=>	$this->input->post('mobile'),

				'code'		=>	$this->input->post('code'),

				'specialist'		=>	$this->input->post('specialist'),

				'user_role'		=>  2,

				'status'		=>  1,

				'salt'			=>	$salt,

				'password' 		=> sha1($salt.sha1($salt.sha1($this->input->post('password')))),

				'location'		=>	$this->input->post('location'),

				'created' => date('Y-m-d H:i:s')

			);

			if($doctor = $this->common_model->insert('users', $user_data)){



				$this->session->set_flashdata('msg_success','Doctor details Add successfully.');

				redirect('superadmin/doctors');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Doctor details Add process failed, Please try again.');

				redirect('superadmin/doctors');

			}

		

		}



		$data['template']='superadmin/add_doctor';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}



	public function alpha_dash_space($str)

	{	if(preg_match("/^([-a-z._ ])+$/i", $str)){

			return TRUE;

		}else{

			$this->form_validation->set_message('alpha_dash_space', 'The %s field may only contain alpha characters & White spaces');

			return FALSE;

		}

	} 



	public function proxy_login($id=0){

		$this->_check_login();

		$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));

        if (empty($data['user']))

        {

            redirect('superadmin/doctors');

        }

         $data = array('user_role'=>2, 'user_id'=>$id);

         $user_data = $this->common_model->proxy_login($data);

        if(!empty($user_data) || $user_data!=''){

			$this->session->unset_userdata('doctor_info');

			$this->session->set_userdata('doctor_info',$user_data);

			redirect('doctor/dashboard');

        }

		

	}



	public function proxy_login_school($id=0){

		$this->_check_login();

		$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));

		if (empty($data['user']))

        {

            redirect('superadmin/schools');

        }

         $data = array('user_role'=>3, 'user_id'=>$id);

         $user_data = $this->common_model->proxy_login($data);

        

        if(!empty($user_data) || $user_data!=''){

			$this->session->unset_userdata('school_info');

			$this->session->set_userdata('school_info',$user_data);
			$test = $this->common_model->get_row('test',array('school_id'=>$id),'',array('test_id','DESC'));

			redirect('school/students/?test_id='.$test->test_id);

        }

		

	}



	public function edit_doctor($id=0){

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['title']='Edit Doctor';

		$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));

        if (empty($data['user']))

        {

            redirect('superadmin/doctors');

        }

		$this->form_validation->set_rules('email', 'Email', 'valid_email|callback_email_check['.$id.']');

		$this->form_validation->set_rules('full_name', 'Doctor Name', 'required|callback_alpha_dash_space');

		$this->form_validation->set_rules('code', 'Doctor Code', 'required|callback_code_check['.$id.']');

    	$this->form_validation->set_rules('mobile', 'Please enter valid Mobile No.', 'trim|callback__check_phone');

		$this->form_validation->set_rules('location', 'Location', 'trim');

		$this->form_validation->set_rules('password', 'Password', 'trim');

		$this->form_validation->set_rules('specialist', 'Doctor specialist', 'required');



		



		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			

			if(!empty($this->input->post('password'))){

				$salt = $this->salt();

			$user_data  = array('salt'=>$salt,'password' => sha1($salt.sha1($salt.sha1($this->input->post('password')))));

			$this->common_model->update('users',$user_data,array('user_id'=>$id));



			}

			$user_data  = array();

			$user_data  = array(

				

				'full_name'		=>	$this->input->post('full_name'),

				'email'			=>	$this->input->post('email'),

				'code'		=>	$this->input->post('code'),

				'specialist'		=>	$this->input->post('specialist'),

				'mobile'		=>	$this->input->post('mobile'),

				'location'		=>	$this->input->post('location'),

				'modified' => date('Y-m-d H:i:s')

			);



			if($this->common_model->update('users', $user_data,array('user_id'=>$id))){

				 $this->session->set_flashdata('msg_success','Doctor details updated successfully.');

				redirect('superadmin/doctors');

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Doctor details updation process failed, Please try again.');

				redirect('superadmin/doctors');

			}

		

		}



		$data['template']='superadmin/edit_doctor';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}




	public function change_status_users(){

	    $this->_check_login(); //check login authentication

	  	$status = $this->input->post('con');

		$id = $this->input->post('id');

		$data=array('status'=>$status);

	    if($this->common_model->update('users',$data,array('user_id '=>$id))){

	    echo true;

		}

	    

	}



	public function delete_users(){

	    $this->_check_login(); //check login authentication

	  	$id = $this->input->post('id');

		if($this->common_model->delete('users',array('user_id'=>$id))){

			$this->common_model->delete('school',array('user_id'=>$id));

			$this->common_model->delete('school_contact',array('school_id'=>$id));

		    echo true;

		}

	}



	public function students($school_id=0,$offset=0){
        $test_id=$this->input->get('test_id');
		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['school_data'] = $this->common_model->get_row('users',array('user_id'=>$school_id,'user_role'=>3));

		if (empty($data['school_data']))

        {

            redirect('superadmin/schools');

        }

		$data['title']='Students';

		$data['school_id']=$school_id;

		$per_page=PER_PAGE;

		$data['student'] = $this->superadmin_model->student($school_id,$offset,$per_page);
       //echo $this->db->last_query();
		//p($data['student']);die;
		
 		$config=backend_pagination();

		$config['base_url'] = base_url().'superadmin/students/'.$school_id.'/';

		$config['total_rows'] = $this->superadmin_model->student($school_id,0,0);

		$config['per_page'] = $per_page;

		$config['uri_segment'] = 4;

		$config['reuse_query_string'] = TRUE;

		if(!empty($_SERVER['QUERY_STRING'])){

			//$config['suffix'] = "?".$_SERVER['QUERY_STRING'];

		}

		if($config['total_rows'] < $offset){

         

            if(!empty($_SERVER['QUERY_STRING'])){

			$suffix = "?".$_SERVER['QUERY_STRING'];

			}else{

			$suffix =''	;

			}	 	

           redirect('superadmin/students/'.$school_id.'/'.$suffix);

    	}

		$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();

 		$data['offset']=$offset;

 		$data['school']=$this->common_model->get_result('users',array('user_role' =>3,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));
 		$data['tests']=$this->common_model->get_result('test',array('school_id'=>$school_id),'',array('test_id','DESC'));
 		
		if(!empty($test_id)){
             $data['deactive_students']=$this->superadmin_model->find_deactive_students($school_id,$test_id); 
       		}
       //shifting deactive ids to last
       if(!empty($data['deactive_students'])){
       	$a=array_column($data['deactive_students'],'student_id');
       	 $stud=$data['student'];$i=0;
       	 foreach($data['student'] as $s){
           if(in_array($s->student_id,$a)){
             	$stud[]=$s;
           	   unset($stud[$i]);
                
           	}$i++;
       	 }
        $data['student']=$stud;
       }
      /**************/

 		$data['template']='superadmin/student';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}





	public function change_status_student(){

	    $this->_check_login(); //check login authentication

	  	$status = $this->input->post('con');

		$id = $this->input->post('id');

		$data=array('status'=>$status);

	    if($this->common_model->update('student',$data,array('student_id'=>$id))){

	    echo true;

		}

	    

	}
function change_test_status_student(){
	$status      = $this->input->post('con');
	$student_id  = $this->input->post('student_id');
	$test_id     = $this->input->post('test_id');
	$school_id   = $this->input->post('school_id');
//$status=0;$student_id=5782;$test_id=37;$school_id=158;
   
		$result = $this->common_model->get_row('deactive_students',array('school_id'=>$school_id,'test_id'=>$test_id));
		
		if(!empty($result)){
			if(!empty($result->deactive_student_ids))
			        $ids=explode(',',$result->deactive_student_ids);
			else $ids=array();    
        
			if($status==1){
				if (($key = array_search($student_id, $ids)) !== false) {
				   unset($ids[$key]);
			    }
			}else if($status==0){
				$ids[]=$student_id;
			}
			if(!empty($ids))
			      $ids=implode(',',$ids);
			else $ids='';  
			
			$data=array('deactive_student_ids'=>$ids);
			if($this->common_model->update('deactive_students',$data,array('school_id'=>$school_id,'test_id'=>$test_id))){
				 $this->session->set_flashdata('msg_success','Student Status updated successfully.'); 
			}else{
				$this->session->set_flashdata('msg_error','Student status not updated.'); 
			}
		}
		
      redirect($_SERVER['HTTP_REFERER']);
		



}


	public function delete_student(){

	    $this->_check_login(); //check login authentication

	  	$id = $this->input->post('id');

		if($this->common_model->delete('student',array('student_id'=>$id))){

		

	    echo true;

		}

	}



	public function add_student($school_id=0){

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['school_data'] = $this->common_model->get_row('users',array('user_id'=>$school_id,'user_role'=>3));

		if (empty($data['school_data']))

        {

            redirect('superadmin/schools');

        }

		$data['title']='Add Student';

		$data['school_id']=$school_id;



		$this->form_validation->set_rules('student_name', 'Student name', 'required|callback_alpha_dash_space');

    	$this->form_validation->set_rules('parent_mobile', 'Mobile No.', 'trim|required|callback__check_phone');


		$this->form_validation->set_rules('class', 'class', 'trim|required');

		$this->form_validation->set_rules('month', 'month', 'trim|required');

		$this->form_validation->set_rules('day', 'day', 'trim|required');

		$this->form_validation->set_rules('year', 'year', 'trim|required');

		$this->form_validation->set_rules('roll_no', 'roll_no', 'trim|required');

			$this->form_validation->set_rules('division', 'division', 'trim|required');

		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$school = $this->common_model->get_row('school', array('user_id'=>$school_id));

			

			if(!empty(max_student($school_id))){

               $unique_id=0;
            	if($temp_student=$this->common_model->get_row('student',array('school_id'=>$school_id),array('unique_id'),array('student_id','desc')))
					$unique_id=$temp_student->unique_id;				

				$part_number =  max_student($school_id,$unique_id);
				

                if($part_number<999)
					  $unique_id   = str_pad($part_number, 3, '0', STR_PAD_LEFT);
		        else  $unique_id   = $part_number;
			}else{

			$unique_id = 001;

			}

			$school->unique_prefix;

			$user_data  = array();

			$user_data  = array(

				

				'student_name'		=>	$this->input->post('student_name'),

				'parent_mobile'		=>	$this->input->post('parent_mobile'),

				'class'				=>	$this->input->post('class'),

				'division'			=>strtoupper($this->input->post('division')),

	

				'roll_no'			=>	$this->input->post('roll_no'),

				'gender'			=>	$this->input->post('gender'),

				'date_of_birth'		=>	$this->input->post('day').'-'.$this->input->post('month').'-'.$this->input->post('year'),

				'school_id'			=>	$school_id,

				'status'			=>	1,

				'unique_id'			=>  $unique_id,

				'school_prefix'		=>	$school->unique_prefix,

				'created' => date('Y-m-d H:i:s')

			);

			if($student_id = $this->common_model->insert('student', $user_data)){
                $test_id=$this->input->post('test_id');
				$this->update_deactive_students($school_id,$test_id,$student_id);
				/*$result=$this->common_model->get_result('deactive_students',array('school_id'=>$school_id));
				
				if(!empty($result)){
					foreach($result as $res){
					$deactive=$res->deactive_student_ids;
					   if(empty($deactive))$deactive_student_ids=$student_id;
					     else $deactive_student_ids=$deactive.','.$student_id;
			
                    $data=array('deactive_student_ids'=>$deactive_student_ids);
				    $this->db->where('school_id',$school_id);
                    $this->common_model->update('deactive_students',$data);
                   
                  }
                }*/

				$this->session->set_flashdata('msg_success','Your Student details add successfully.');

				redirect('superadmin/students/'.$school_id);

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Your Student details add process failed, Please try again.');

				redirect('superadmin/students/'.$school_id);

			}

		

		}

		$data['school']=$this->common_model->get_result('users',array('user_role' =>3,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

		$data['template']='superadmin/add_student';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}
 public function edit_student_bytest_id($school_id=0,$id=0){
        $this->_check_login();
		date_default_timezone_set('Asia/Kolkata');
		
		//$test_id=$_REQUEST['test_id'];

		$data['school_data'] = $this->common_model->get_row('users',array('user_id'=>$school_id,'user_role'=>3));

		if (empty($data['school_data']))

        {

            redirect('superadmin/schools');

        }

		$data['title']='Edit Student';

		$data['student'] = $this->common_model->get_row('student',array('student_id'=>$id));
		

        if (empty($data['student']))

        {

            redirect('superadmin/students');

        }
 
       
		
		$this->form_validation->set_rules('class', 'class', 'trim|required');
		$this->form_validation->set_rules('roll_no', 'roll_no', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$user_data  = array();
			$test_id=$this->input->post('test_id');
						
           
				$user_data['class_id']		=  $this->input->post('class');
				$user_data['division']		=  strtoupper($this->input->post('division'));
				$user_data['roll_no']		=  $this->input->post('roll_no');				
				$user_data['modified']      =  date('Y-m-d H:i:s');
			
               $test_id=$this->input->post('test_id');

              $result = $this->common_model->get_row('student_test',array('student_id'=>$id,'test_id'=>$test_id));

          if(!empty($result)){
               $doctor = $this->common_model->update('student_test', $user_data,array('student_id'=>$id,'test_id'=>$test_id));
           }
           else{
           	    $user_data['student_id']		=  $id;
           	    $user_data['test_id']		    =  $this->input->post('test_id');
           	    $user_data['created']		    =  date('Y-m-d H:i:s');
           	    $user_data['modified']		    =  date('Y-m-d H:i:s');

                $doctor = $this->common_model->insert('student_test', $user_data);
             }
			

		    if(!empty($doctor)){
		       	      $this->session->set_flashdata('msg_success','Your Student details Update successfully.');						
		           
					 redirect('superadmin/students/'.$school_id.'/?test_id='.$test_id);
		       }

				
				

			else{

				$this->session->set_flashdata('msg_error','Sorry! Your Student details Update process failed, Please try again.');

				redirect('superadmin/students/'.$school_id.'/?test_id='.$test_id);

			}

		

		}

		$data['school']=$this->common_model->get_result('users',array('user_role' =>3,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

		$test_id=$this->input->get('test_id');
		$data['test'] = $this->common_model->get_row('student_test',array('student_id'=>$id,'test_id'=>$test_id));

		if(!empty($data['test'])){
			$data['student']->class=$data['test']->class_id;
			$data['student']->division=$data['test']->division;
			$data['student']->roll_no=$data['test']->roll_no;
			//$data['student']->student_test_id=$data['test']->student_test_id;

		}

		$data['template']='superadmin/edit_student';

	    $this->load->view('templates/superadmin/superadmin_template',$data);
}


	public function edit_student($school_id=0,$id=0){ 

		$this->_check_login();
		date_default_timezone_set('Asia/Kolkata');

		$data['school_data'] = $this->common_model->get_row('users',array('user_id'=>$school_id,'user_role'=>3));

		if (empty($data['school_data']))

        {

            redirect('superadmin/schools');

        }

		$data['title']='Edit Student';

		$data['student'] = $this->common_model->get_row('student',array('student_id'=>$id));

        if (empty($data['student']))

        {

            redirect('superadmin/students');

        }
 
      // if(!(isset($_POST['test_id']) && $_POST['test_id'])){
       	    $this->form_validation->set_rules('student_name', 'Student name', 'required|callback_alpha_dash_space');
	    	$this->form_validation->set_rules('parent_mobile', 'Mobile No.', 'trim|required|callback__check_phone');
	    	$this->form_validation->set_rules('month', 'month', 'trim|required');
			$this->form_validation->set_rules('day', 'day', 'trim|required');
			$this->form_validation->set_rules('year', 'year', 'trim|required');
       //}
		
		$this->form_validation->set_rules('class', 'class', 'trim|required');
		$this->form_validation->set_rules('roll_no', 'roll_no', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$user_data  = array();
			//$test_id=$this->input->post('test_id');

						
           // if(!(isset($_POST['test_id']) && $_POST['test_id']!='')){
				$user_data['student_name']		=	$this->input->post('student_name');
				$user_data['parent_mobile']		=	$this->input->post('parent_mobile');
				$user_data['gender']			=	$this->input->post('gender');
				$user_data['date_of_birth']		=	$this->input->post('day').'-'.$this->input->post('month').'-'.$this->input->post('year');
			//}

				$user_data['class']			=  $this->input->post('class');
				$user_data['division']		=  strtoupper($this->input->post('division'));
				$user_data['roll_no']		=  $this->input->post('roll_no');
				$user_data['class']			=  $this->input->post('class');
				$user_data['modified']      =  date('Y-m-d H:i:s');
			

			if($doctor = $this->common_model->update('student', $user_data,array('student_id'=>$id))){



				$this->session->set_flashdata('msg_success','Your Student details Update successfully.');
				
            //if(empty($test_id)){
            	redirect('superadmin/students/'.$school_id);
           // }
			//else  {
				// redirect('superadmin/students/'.$school_id.'/?test_id='.$test_id);
				//}

			}else{

				$this->session->set_flashdata('msg_error','Sorry! Your Student details Update process failed, Please try again.');

				redirect('superadmin/students/'.$school_id);

			}

		

		}

		$data['school']=$this->common_model->get_result('users',array('user_role' =>3,'	status' =>1),array('full_name','user_id'),array('full_name','asc'));

		$data['template']='superadmin/edit_student';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}



	public function importContacts()
    {	//p($_POST);p($_FILES);die;
       // ini_set('memory_limit', '-1');
        $this->_check_login();
		date_default_timezone_set('Asia/Kolkata');
    	$school_id =  $this->input->post('school');
    	$test_id =  $this->input->post('test_id');
		
    	$config['upload_path']   = './assets/uploads/imports';
        $config['allowed_types'] = 'csv';
        $config['max_size']      = '10000';
        $this->load->library('upload', $config);
        $this->load->library('csvimport');
        $this->upload->initialize($config);
        //read file from path
        if (!$this->upload->do_upload('importContactsFile')) {
            // $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('msg_error', 'Not Uploaded or Incorrect Format.');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $file_data = $this->upload->data();
            $file_path = FCPATH.'assets/uploads/imports/' . $file_data['file_name'];
            if ($csv_array=$this->csvimport->get_array($file_path)) {
              	unlink($file_path);
                if(empty($csv_array)){
                $this->session->set_flashdata('msg_error', 'Uploaded file is empty.');
                   redirect($_SERVER['HTTP_REFERER']);
                }else if(!empty($csv_array)){
                    $error=array();
                    $i=1;
                    foreach ($csv_array as $key => $row) {
                       if(empty($row['Name']))
                        {
                            $error[] = 'row number : ' . $i . ' name is required';
                        }
                        if(empty($row['Class']))
                        {
                            $error[] = 'row number : ' . $i . ' class is required';
                        }
                        if(empty($row['Roll No']))
                        {
                            $error[] = 'row number : ' . $i . ' Roll No is required';
                        }
                        if(empty($row['Division']))
                        {
                            $error[] = 'row number : ' . $i . ' Division is required';
                        }
                        if(empty($row['Gender']))
                        {
                            $error[] = 'row number : ' . $i . ' Gender is required';
                        }
                       if(!empty($row['Date of Birth'])){
                          if (!preg_match("/^(0[1-9]|[1-2][0-9]|3[0-1])-(0[1-9]|1[0-2])-[0-9]{4}$/",$row['Date of Birth']))
                            {
    	                     $error[]='row number : ' . $i . ' Date format("eg. 01-12-2018") of Date of Birth is invalid Please check Date'.$row['Date of Birth'];
                            }
                       }
                       else if(empty($row['Date of Birth']))
                        {
                            $error[] = 'row number : ' . $i . ' Date of Birth is required';
                        }
                       	if (!empty($row['Parent Mobile'])) {
                             //if (!preg_match('/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/', $row['Parent Mobile'])) {
                       		if(preg_match('/^[0-9]{10}+$/',$row['Parent Mobile'])){
                                 $error[] = 'row number : ' . $i . 'parent mobile is invalid';
                            }
                        }elseif(empty($row['Parent Mobile'])){
                             $error[] = 'row number : ' . $i . ' Parent Mobile is required';
                        }
                        $i++;
                    }

                   if(!empty($error))
                    {

                        $errormsg = '';

                        foreach ($error as $err) {

                            $errormsg .= $err . '<br/>';

                        }

                        $this->session->set_flashdata('msg_error', 'Error occured in following rows</br>' . $errormsg . ' Please correct this and import again.');

                       redirect($_SERVER['HTTP_REFERER']);

                    }else{

             $class_names=array();

				foreach ($csv_array as $rowData) {



				$class_id = $this->common_model->get_row('class', array('class_name'=>$rowData['Class']));

            

				//$class_id = $this->common_model->get_row('class', array('class_name'=>$rowData['Class']));

				

				if(!empty($class_id)){



				$final_class_id=$class_id->id;

				}else{





				$class_names[]=strtoupper($rowData['Class']);

				}

				}

              

				if(!empty($class_names))

				{

				$classmsg = '';

				$class_names=array_unique($class_names);

				foreach ($class_names as $class) {

				$classmsg .= $class . '<br/>';

				}

				$this->session->set_flashdata('msg_error', 'Following Class not Available in Database Please ADD these classes</br>' . $classmsg);

				redirect($_SERVER['HTTP_REFERER']);

				}







                    	$school = $this->common_model->get_row('school', array('user_id'=>$this->input->post('school')));
						//echo $this->db->last_query();
              // p($school);die;
                         foreach ($csv_array as $rowData) {

	                        if(!empty($school) && !empty(max_student($school->user_id))){

	                        	$unique_id=0;
	                        	if($temp_student=$this->common_model->get_row('student',array('school_id'=>$school->user_id),array('unique_id'),array('student_id','desc')))							
									{
										$unique_id=$temp_student->unique_id;	
										}		
                              
								 $part_number =  max_student($school->user_id,$unique_id);
                             

                                 if($part_number<999)
								    $unique_id     = str_pad($part_number, 3, '0', STR_PAD_LEFT);
                                 else  $unique_id  = $part_number;
							}else{

								$unique_id = 001;

							}
                         //echo '<br>'.$unique_id;die;
							$class_id = $this->common_model->get_row('class', array('class_name'=>$rowData['Class']));

                            

                              if(!empty($class_id)){



				             $final_class_id=$class_id->id;

				                  }



	                        $dataInsert   = array(

	                            'student_name' => $rowData['Name'],

	                            'class' => $final_class_id,

	                            'school_id'	=>	$this->input->post('school'),

	                            'unique_id'	=>  $unique_id,

								'school_prefix'	=>	$school->unique_prefix,

								'status'		=>	1,

	                            'parent_mobile' => $rowData['Parent Mobile'],

	                            'roll_no'		=>	$rowData['Roll No'],

	                            'division'		=>strtoupper($rowData['Division']),

								'gender'=>	$rowData['Gender'],

								'date_of_birth'	=>	$rowData['Date of Birth'],

	                          	'created' => date('Y-m-d H:i:s'),

	                        );

	                         $insertResult = $this->common_model->insert('student', $dataInsert);
                            $this->update_deactive_students($school_id,$test_id,$insertResult);


                        }

                        if (!empty($insertResult)) {

                        	

                            $this->session->set_flashdata('msg_success', 'Student information added successfully.');

                        } else {

                        	

                            $this->session->set_flashdata('msg_error', 'Unable to add.');

                        }

                        redirect($_SERVER['HTTP_REFERER']);

                    }

                }else {

                	

                    $this->session->set_flashdata('msg_error', 'Unable to get file');

                    redirect($_SERVER['HTTP_REFERER']);

                }   

            }else{

            	

                $this->session->set_flashdata('msg_error', 'Unable to get file');

               redirect($_SERVER['HTTP_REFERER']);

            } 

        }               

    }



    public function change_all_status($tablename='')

    {     

        $this->_check_login(); //check login authentication   

        $data['title']='change_all_status';

        $tablename = base64_decode($_POST['table_name']);

        $col_name  = base64_decode($_POST['col_name']);

            $default_arr=array('status'=>FALSE); 

            $status='';            

            $count= count($_POST['row_id']);

            

            for ($i=0; $i < $count ; $i++){

                if($_POST['status']==1 || $_POST['status']==2){

                    if($_POST['status']==1){

                        $update_status= array('status'=>1);

                    }elseif($_POST['status']==2){

                        $update_status= array('status'=>0);

                    }

                    $this->common_model->update($tablename,$update_status,array($col_name=>$_POST['row_id'][$i]));
                  //echo $this->db->last_query();
                    $default_arr=array('status'=>TRUE);

                }else{

                    $this->common_model->delete($tablename,array($col_name=>$_POST['row_id'][$i]));

                    $default_arr=array('status'=>TRUE);

                } 

            }

            header('Content-Type: application/json');

            echo json_encode($default_arr);        

       

    }



    





	public function schools_dr_list()

    {  	$array = array();

		$school_dr = $this->superadmin_model->schools_dr_list($this->input->post('id'));

		if(!empty($school_dr)){

		$array = array_column($school_dr, 'user_id');

		}

    	$school=get_school();

		if ($school) {

			$optionData='';

           		foreach ($school as $row) {

                	if(in_array($row->user_id, $array)){$selected = "selected";}else{$selected = "";}

                    $optionData .= "<option ".$selected." value='".$row->user_id."'>" . $row->full_name ."</option>";

                }

                echo json_encode(array('status' => 'success','optionData' => $optionData));

                die();

		}

	}



	public function importschool()

    {  	$this->_check_login();
    	$this->form_validation->set_rules('doctor','doctor', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');
		if ($this->form_validation->run() == TRUE){
			$doctor=$this->input->post('doctor');
			$this->superadmin_model->schools_list($doctor);
			$school=$this->input->post('school[]');
			if(!empty($school)) {
				foreach ($school as $row) {
					$this->superadmin_model->update_schools_list($doctor,$row);
                }
			}

			$this->session->set_flashdata('msg_success', 'Assign school successfully');

			redirect($_SERVER['HTTP_REFERER']);
		}else{
			$this->session->set_flashdata('msg_error', 'Unable to your request');
 			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->session->set_flashdata('msg_error', 'Unable to get your request');
     	redirect($_SERVER['HTTP_REFERER']);


	}


		public function test_report($student_id=0,$test_id='')
    {   
	    $this->load->library('M_pdf');	
    	$this->_check_login();
    	if(empty($test_id)){
    		$this->session->set_flashdata('msg_error','Test id is empty');
    	}

    	$data['student']     = $this->common_model->get_row('student',array('student_id'=>$student_id));
    	$data['school_info'] = school_info($data['student']->school_id);
    	//p($data['school_info']);die;
    	$class_name          = $this->common_model->get_row('class',array('id'=>$data['student']->class));
        $data['class_name']=$class_name->class_name;

		$school_id=$data['student']->school_id;

        if (empty($data['student']))
        {
            redirect('school/students');
        }

    	$test_student= $this->common_model->get_row('student_test', array('student_id'=>$student_id,'test_id'=>$test_id));
    	//echo $this->db->last_query();
      //p($test_student);

        if(!empty($test_student)){
     		$data['general'] 			 = json_decode($test_student->general);
     		$data['eye'] 				 = json_decode($test_student->eye);
			$data['dental'] 			 = json_decode($test_student->dental);
     		$data['ent'] 				 = json_decode($test_student->ent);
     		$data['cardiovascular'] 	 = json_decode($test_student->cardiovascular);
     		$data['examination'] 		 = json_decode($test_student->examination);
     		$data['upload_file'] 		 = json_decode($test_student->upload_file);
     		$data['general_per'] 		 = $test_student->general_per;
     		$data['eye_per'] 			 = $test_student->eye_per;
     		$data['dental_per'] 		 = $test_student->dental_per;
     		$data['final_notes'] 		 = $test_student->final_notes;
     		$data['ent_per'] 			 = $test_student->ent_per;
     		$data['cardiovascular_per']  = $test_student->cardiovascular_per;
     		$data['examination_per'] 	 = $test_student->examination_per;
     		$data['scal'] 				 = json_decode($test_student->scal);
			$data['created'] 			 = $test_student->created;
			$data['examinationswitch']   = $test_student->examinationswitch;
     		$data['eyeswitch']			 = $test_student->eyeswitch;
     		$data['generalswitch']		 = $test_student->generalswitch;
     		$data['dentalswitch']		 = $test_student->dentalswitch;
     		$data['entswitch']			 = $test_student->entswitch;
     		$data['cardiovascularswitch']= $test_student->cardiovascularswitch;						
			$data['general_notes']         = $test_student->general_notes;			
			$data['eye_notes']             = $test_student->eye_notes;			
			$data['dental_notes']          = $test_student->dental_notes;			
			$data['ent_notes']             = $test_student->ent_notes;			
			$data['cardiovascular_notes']  = $test_student->cardiovascular_notes;			
			$data['examination_notes']     = $test_student->examination_notes;			     
     	}
     	//p($data);die;
         $html= $this->load->view('school/test_report',$data,true);
		$pdfFilePath = "test.pdf";
		$this->m_pdf->pdf->WriteHTML($html);

//download it D save F.

  		$this->m_pdf->pdf->Output($pdfFilePath, "I");   
    }



    public function pre($student_id=0)

	{  	$file_path = './assets/uploads/files/'.$_POST['key'];

		$this->superadmin_model->pre($_POST['key'],$student_id);

		unlink($file_path);

		echo json_encode(0);

	}





	public function add_test($student_id=0)

	{ 

		$data['template']='superadmin/add_test';

	    $this->load->view('templates/superadmin/superadmin_template',$data); 

	}





public function _check_phone($phone){		

	   	//if(preg_match('/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/',$phone)){
	   	if(preg_match('/^[0-9]{10}+$/',$phone)){

			return true;

		} else {

			$this->form_validation->set_message('_check_phone', '%s '.$phone);

			return false;

		}

	}


    // class



	public function classes($offset=0){

		$this->_check_login();	

		$data['title']='Class';		

		$per_page=PER_PAGE;

		$data['class']=$this->superadmin_model->get_class($offset,$per_page);

 		$config=backend_pagination();

		$config['base_url'] = base_url().'superadmin/classes/';

		$config['total_rows'] = $this->superadmin_model->get_class(0,0);



		$config['per_page'] = $per_page;

		$config['uri_segment'] = 3;

		$config['reuse_query_string'] = TRUE;

		if(!empty($_SERVER['QUERY_STRING'])){

			$config['suffix'] = "?".$_SERVER['QUERY_STRING'];

		}

		if($config['total_rows'] < $offset){

         

            if(!empty($_SERVER['QUERY_STRING'])){

			$suffix = "?".$_SERVER['QUERY_STRING'];

			}else{

			$suffix =''	;

			}	 	

           redirect('superadmin/classes/'.$suffix);

    	}

		$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();

 		$data['offset']=$offset;

 	

 		$data['template']='superadmin/classes';

	    $this->load->view('templates/superadmin/superadmin_template',$data);

	}





    public function add_classes()

    {

		$this->_check_login();

        $this->form_validation->set_rules('class_order', 'Class order', 'trim|required');

		$this->form_validation->set_rules('class_name', 'Class name', 'trim|required');

		$this->form_validation->set_error_delimiters('<div class="validation-error-label">', '</div>');

		if ($this->form_validation->run() == TRUE)	{

			$class_name= $this->common_model->get_row('class', array('class_name'=>$this->input->post('class_name')));

			$user_data  = array();

			$class_data  = array(

				'class_name'		=>	$this->input->post('class_name'),

				'class_order'       =>  $this->input->post('class_order')

			);

			if($this->input->post('action_type')==2)

			{

	            $class_name= $this->common_model->get_row('class', array('class_name'=>$this->input->post('class_name'),'id!='=>$this->input->post('id')));

		  		if(!empty($class_name)){

		  			$this->session->set_flashdata('msg_error','Sorry! Your Class not update This Class Name already added. ');

        			redirect('superadmin/classes');

		        }

				$this->common_model->update('class', $class_data,array('id'=>$this->input->post('id')));

					$this->session->set_flashdata('msg_success','Your Class Update successfully.');

				redirect('superadmin/classes');



			}else{

				if(!empty($class_name)){

					$this->session->set_flashdata('msg_error','Sorry! This Class already added, Please try again. ');

        			redirect('superadmin/classes');

		        }else {

					$this->common_model->insert('class', $class_data);

            	}

				$this->session->set_flashdata('msg_success','Your Class add successfully.');

					redirect('superadmin/classes');

			}

		}else{

			$this->session->set_flashdata('msg_error','Sorry! Your Class add process failed, Please try again.');

			redirect('superadmin/classes');

		}

	}



	public function delete_class(){

	    $this->_check_login(); //check login authentication

	  	$id = $this->input->post('id');

		if($this->common_model->delete('class',array('id'=>$id))){

		    echo true;

		}

	}

	public function not_found(){

	    $this->load->view('superadmin/404_page');

	}



	public function students_information($id=0){

		$this->_check_login();

		$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));

		if(empty($data['user']))

			redirect('superadmin/schools');

		$filename = $data['user']->full_name.'-'.date('d-m-Y');

		$result= $this->superadmin_model->student_info_csv($id);


   	if(!empty($result)){

			header('Content-Description: File Transfer');

			header('Content-Type: application/vnd.ms-excel');

			header("Content-Disposition: attachment; filename=\"".$filename.".csv\"");



			 $handle = fopen('php://output', 'w');

           fputcsv($handle, array('Patient ID','First Name','Last Name','Date of Birth','Gender','Eyewear'));

            $i = 1;



        foreach ($result as $data) {

        	$name=explode(' ', $data->student_name);

        	$fname='';$lname='';

        	if(sizeof($name)>1)

        	{

        		$lname=$name[sizeof($name)-1];

        		unset($name[sizeof($name)-1]);

        		$fname=implode(' ', $name); 

        	}else{

        		$fname=$data->student_name;

        	}

          fputcsv($handle, array($data->school_prefix.'-'.$data->unique_id,ucfirst($fname),ucfirst($lname),date("Y-m-d", strtotime($data->date_of_birth)),ucfirst(mb_substr($data->gender,0,1)),'None'));

               

                $i++; 

				}

         fclose($handle);

            exit;

        }else{

            $this->session->set_flashdata('msg_error', 'No Records available');

            redirect('superadmin/schools');

        }



	}

	



   	public function school_csv($id=0){
		$this->_check_login();
	  	$data['user'] = $this->common_model->get_row('users',array('user_id'=>$id));
		if(empty($data['user']))
			redirect('superadmin/schools');
		$filename   = $data['user']->full_name.'-'.date('d-m-Y');
		$test_id    = $this->input->post('test_id');
		$result     = $this->superadmin_model->student_test_csv($id,$test_id);
        $this->load->library('excel');
	    //activate worksheet number 1
        $this->excel->setActiveSheetIndex(0);
    //name the worksheet
		$this->excel->getActiveSheet()->setTitle('WIP - Tracker');
	    $data1['order_csv'] = array();
   $data1['order_csv'][0] = array(
						'#S.No.' 					=> '#S.No.',
						'Student Name' 				=> 'Student Name',
						'Class' 					=> 'Class',
						'Division' 					=> 'Division',
						'Roll No' 					=> 'Roll No',
						'Student Id' 				=> 'Student Id',
						'Date of Birth' 			=> 'Date of Birth',
						'Gender' 					=> 'Gender',
						'Parent Mobile' 			=> 'Parent Mobile',
						'Screeing Date' 			=> 'Screeing Date',
						'Weight/ KGS' 				=> 'Weight/ KGS',
						'Height/ CMS' 				=> 'Height/ CMS',
						'BMI' 						=> 'BMI',
						'BMI %'						=> 'BMI %',
						'BMI Percentile Status' 	=> 'BMI Percentile Status',
						'Right Eye Sphere' 			=> 'Right Eye Sphere',
						'Right Eye Cylindrical' 	=> 'Right Eye Cylindrical',
						'Right Eye Axis IN' 		=> 'Right Eye Axis IN',
						'Right EyePupil Size' 	    => 'Right EyePupil Size',
						'Right Eye Spherical Equivalent' => 'Right Eye Spherical Equivalent',
						'Left Eye Sphere' 			=> 'Left Eye Sphere',
						'Left Eye Cylindrical' 		=> 'Left Eye Cylindrical',
						'Left Eye Axis IN' 			=> 'Left Eye Axis IN',
						'Left EyePupil Size' 		=> 'Left EyePupil Size',
						'Left Eye Spherical Equivalent' => 'Left Eye Spherical Equivalent',
						'Screeing Result' 			=> 'Screeing Result',
						'Myopia' 					=> 'Myopia',
						'Hyperopia' 				=> 'Hyperopia',
						'Astigmatism' 				=> 'Astigmatism',
						'Anisometropia' 			=> 'Anisometropia',
						'Strabismus' 				=> 'Strabismus',
						'Anisocoria' 				=> 'Anisocoria',
						'Eye %'						=> 'Eye %',
						'Ear Wax' 					=> 'Ear Wax',
						'Ear Drum' 					=> 'Ear Drum',
						'Ear' 						=> 'Ear',
						'Nosal Track' 				=> 'Nosal Track',
						'Nose' 						=> 'Nose',
						'Tonsils' 					=> 'Tonsils',
						'Throat' 					=> 'Throat',
						'ENT %'						=> 'ENT %',
						'Pulse' 					=> 'Pulse',
						'Pulse Status' 				=> 'Pulse Status',
						'Spirometry' 				=> 'Spirometry',
						'Spirometry Status' 		=> 'Spirometry Status',
						'Respiratory Rate' 			=> 'Respiratory Rate',
						'Resporatory Rate Status' 	=> 'Resporatory Rate Status',
						'Oximetry' 					=> 'Oximetry',
						'Oximetry Status' 			=> 'Oximetry Status',
						'Heart Sound' 				=> 'Heart Sound',
						'Lung Sound' 				=> 'Lung Sound',
						'Cardiovascular %'			=> 'Cardiovascular %',
						'Image 1'				    => 'Image 1' ,
						'Image 2' 				    => 'Image 2',
						'Gum Inflammation' 			=> 'Gum Inflammation',
						'Sensitivity' 				=> 'Sensitivity',
						'Bleeding' 					=> 'Bleeding',
						'Filling In Teeth' 			=> 'Filling In Teeth',
						'Caries' 					=> 'Caries',
						'Alignment Of Teeth' 		=> 'Alignment Of Teeth',
						'Bad Odour' 				=> 'Bad Odour',
						'Plaque' 					=> 'Plaque',
						'Dental %'					=> 'Dental %',
						'Palor' 					=> 'Palor',
						'Lymphadenopathy' 			=> 'Lymphadenopathy',
						'Edema' 					=> 'Edema',
						'Skin' 						=> 'Skin',
						'Cyanosis' 					=> 'Cyanosis',
						'Icterus' 					=> 'Icterus',
						'Allergy' 					=> 'Allergy',
						'Stomach Ache' 				=> 'Stomach Ache',
						'CNS Parameter' 			=> 'CNS Parameter',
						'Nail Hygiene' 				=> 'Nail Hygiene',
						'Hair Hygiene' 				=> 'Hair Hygiene',
						'General %' 				=> 'General %',
					);
				$i = 1;
				$color = array(
					'#FFFFFFFF',
					'#EDEDEDED'
				);
				$code = 0;
				$styleArray = array(
					'borders' => array(
						'allborders' => array(
							'style' => PHPExcel_Style_Border::BORDER_THIN
						)
					) ,
					'alignment' => array(
						'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					)
				);


     foreach ($result as $data) {

	        $general  		= json_decode($data->general);
	     	$eye      		= json_decode($data->eye);
			$dental   		= json_decode($data->dental);
     		$ent      		= json_decode($data->ent);
     		$cardiovascular = json_decode($data->cardiovascular);
     		$examination 	= json_decode($data->examination);
			$upload_file 	= json_decode($data->upload_file);
			if(isset($upload_file[0]) && $upload_file[0]!='')$image1='Yes';else $image1='N/A';
			if(isset($upload_file[1]) && $upload_file[1]!='')$image2='Yes';else $image2='N/A';

	        $weight     = "";
     		$height     = "";
     		$bmi        = "";
    		$bmi_status = "";

			if (!empty($general->weight)){ $weight = $general->weight; } else{ $weight = 'N/A';}
	        if (!empty($general->height)){ $height = $general->height; } else{ $height = 'N/A';}
	        if (!empty($general->bmi)){ $bmi = $general->bmi;} else{ $bmi = 'N/A';}
	        if (!empty($general->bmi_status)){ $bmi_status =  $general->bmi_status;} else{ $bmi_status =  'N/A';}
	        
			$right_sp 		 ="";
	        $right_cy 		 ="";
	        $right_axis 	 ="";
			$right_pupil_size="";
			$right_se 		 ="";
			$left_sp 		 ="";
			$left_cy 		 ="";
			$left_axis 		 ="";
			$left_pupil_size ="";
			$left_se 		 ="";
			$screeing_result ="";
			$myopia 		 ="";
			$hyperopia 		 ="";
			$astigmatism 	 ="";
			$anisometropia   ="";
			$strabismus 	 ="";
			$anisocoria 	 ="";

          if (!empty($eye->right_sp)){ $right_sp = $eye->right_sp;} else{ $right_sp ='N/A';}

          if (!empty($eye->right_cy)){ $right_cy = $eye->right_cy;} else{ $right_cy ='N/A';}

          if (!empty($eye->right_axis)){$right_axis = $eye->right_axis;} else{$right_axis =  'N/A';}

          if (!empty($eye->right_pupil_size)){$right_pupil_size = $eye->right_pupil_size;} else{ $right_pupil_size = 'N/A';}

          if (!empty($eye->right_se)){ $right_se = $eye->right_se;} else{$right_se ='N/A';}

          if (!empty($eye->left_sp)){ $left_sp = $eye->left_sp;} else{ $left_sp = 'N/A';}

          if (!empty($eye->left_cy)){ $left_cy = $eye->left_cy;} else{ $left_cy ='N/A';}

          if (!empty($eye->left_axis)){ $left_axis = $eye->left_axis;} else{ $left_axis = 'N/A';}

          if (!empty($eye->left_pupil_size)){ $left_pupil_size = $eye->left_pupil_size;} else{ $left_pupil_size = 'N/A';}

          if (!empty($eye->left_se)){$left_se = $eye->left_se;} else{$left_se = 'N/A';}

          if (!empty($eye->screeing_result)){$screeing_result = $eye->screeing_result;} else{$screeing_result= 'N/A';}

          if (!empty($eye->myopia)){ $myopia=$eye->myopia;} else{$myopia = 'N/A';}

          if (!empty($eye->hyperopia)){$hyperopia = $eye->hyperopia;} else{ $hyperopia='N/A';}

          if (!empty($eye->astigmatism)){ $astigmatism = $eye->astigmatism;} else{ $astigmatism='N/A';}

          if (!empty($eye->anisometropia)){ $anisometropia = $eye->anisometropia;} else{ $anisometropia = 'N/A';}

          if (!empty($eye->strabismus)){$strabismus = $eye->strabismus;} else{ $strabismus='N/A';}

          if (!empty($eye->anisocoria)){$anisocoria = $eye->anisocoria;} else{ $anisocoria='N/A';}


          $ear_wax 		="";
          $ear_drum 	="";
          $ear 			="";
          $nosal_track  ="";
          $nose     	="";
          $tonsils  	="";
          $throat   	="";

          if (!empty($ent->ear_wax)){$ear_wax = $ent->ear_wax;} else{ $ear_wax ='N/A';}

          if (!empty($ent->ear_drum)){$ear_drum = $ent->ear_drum;} else{$ear_drum ='N/A';}

          if (!empty($ent->ear)){$ear =$ent->ear;} else{$ear ='N/A';}

          if (!empty($ent->nosal_track)){$nosal_track = $ent->nosal_track;} else{$nosal_track ='N/A';}

          if (!empty($ent->nose)){$nose= $ent->nose;} else{$nose='N/A';}

          if (!empty($ent->tonsils)){ $tonsils = $ent->tonsils;} else{ $tonsils='N/A';}

          if (!empty($ent->throat)){  $throat = $ent->throat;} else{  $throat ='N/A';}


          $pulse              ="";
          $pulse_status       ="";
          $spirometry 		  ="";
          $spirometry_status  ="";
          $respiratory 	  ="";
          $resporatory_status ="";
          $oximetry 		  ="";
          $oximetry_status    ="";
          $mummur 			  ="";
          $auscultation 	  ="";


          if (!empty($cardiovascular->pulse)){ $pulse = $cardiovascular->pulse;} else{ $pulse = 'N/A';}

          if (!empty($cardiovascular->pulse_status)){$pulse_status = $cardiovascular->pulse_status;} else{ $pulse_status = 'N/A';}

          if (!empty($cardiovascular->spirometry)){$spirometry = $cardiovascular->spirometry;} else{ $spirometry ='N/A';}

          if (!empty($cardiovascular->spirometry_status)){ $spirometry_status = $cardiovascular->spirometry_status;} else{ $spirometry_status='N/A';}

          if (!empty($cardiovascular->respiratory)){ $respiratory = $cardiovascular->respiratory;} else{ $respiratory = 'N/A';}

          if (!empty($cardiovascular->resporatory_status)){ $resporatory_status = $cardiovascular->resporatory_status;} else{ $resporatory_status ='N/A';}
         
          if (!empty($cardiovascular->oximetry)){$oximetry = $cardiovascular->oximetry;} else{$oximetry = 'N/A';}

          if (!empty($cardiovascular->oximetry_status)){$oximetry_status = $cardiovascular->oximetry_status;} else{ $oximetry_status = 'N/A';}

          if (!empty($cardiovascular->mummur)){ $mummur = $cardiovascular->mummur;} else{$mummur =  'N/A';}

          if (!empty($cardiovascular->auscultation)){$auscultation= $cardiovascular->auscultation;} else{ $auscultation= 'N/A';}

					$gum_info     = "";
					$sensitivity  = "";
					$bleeding     = "";
					$filling      = "";
					$caries       = "";
					$alignment    = "";
					$bad_odor     = "";
					$plaque       = "";


      	  if (!empty($dental->gum_info)){$gum_info =  $dental->gum_info;} else{ $gum_info = 'N/A';}

          if (!empty($dental->sensitivity)){ $sensitivity = $dental->sensitivity;} else{ $sensitivity = 'N/A';}

          if (!empty($dental->bleeding)){$bleeding =  $dental->bleeding;} else{ $bleeding =  'N/A';}

          if (!empty($dental->filling)){$filling = $dental->filling;} else{$filling= 'N/A';}

          if (!empty($dental->caries)){ $caries = $dental->caries;} else{ $caries = 'N/A';}

          if (!empty($dental->alignment)){$alignment= $dental->alignment;} else{$alignment = 'N/A';}

          if (!empty($dental->bad_odor)){$bad_odor = $dental->bad_odor;} else{ $bad_odor ='N/A';}

          if (!empty($dental->plaque)){$plaque= $dental->plaque;} else{ $plaque='N/A';}

          $palor           = "";
          $lymphadenopathy = "";
          $edema           = "";
          $skin            = "";
          $cyanosis        = "";
          $icterus         = "";
          $allergy         = "";
          $stomach_ache    = "";
          $cns             = "";
          $nail            = "";
          $hair            = "";


          if (!empty($examination->palor)){$palor= $examination->palor;} else{$palor = 'N/A';}

          if (!empty($examination->lymphadenopathy)){$lymphadenopathy= $examination->lymphadenopathy;} else{ $lymphadenopathy= 'N/A';}

          if (!empty($examination->edema)){ $edema = $examination->edema;} else{$edema = 'N/A';}

          if (!empty($examination->skin)){ $skin = $examination->skin;} else{ $skin ='N/A';}

          if (!empty($examination->cyanosis)){$cyanosis= $examination->cyanosis;} else{ $cyanosis='N/A';}

          if (!empty($examination->icterus)){ $icterus = $examination->icterus;} else{ $icterus = 'N/A';}

          if (!empty($examination->allergy)){$allergy = $examination->allergy;} else{$allergy= 'N/A';}

          if (!empty($examination->stomach_ache)){$stomach_ache = $examination->stomach_ache;} else{ $stomach_ache = 'N/A';}

          if (!empty($examination->cns)){$cns = $examination->cns;} else{$cns =  'N/A';}

          if (!empty($examination->nail)){$nail = $examination->nail;} else{$nail= 'N/A';}

          if (!empty($examination->hair)){$hair = $examination->hair;} else{ $hair = 'N/A';}



		 if (!empty($data->generalswitch) && $data->generalswitch=='1' ){ 
			$general_per_total = ($data->general_per * 100) / TOTAL_GENERAL;
		 }else {
			 $general_per_total = '0';
		 }

		if (!empty($data->eyeswitch) && $data->eyeswitch=='1' ){ 
			$eye_per_total = ($data->eye_per * 100) / TOTAL_EYE;
		 }else {
			 $eye_per_total = '0';
		  }

		if (!empty($data->dentalswitch) && $data->dentalswitch=='1' ){ 
			$dental_per_total = ($data->dental_per * 100) / TOTAL_DENTAL;
		 }else {
			 $dental_per_total = '0';
		   }

		if (!empty($data->entswitch) && $data->entswitch=='1' ){ 
			$ent_per_total = ($data->ent_per * 100) / TOTAL_ENT;
		  }else {
			 $ent_per_total = '0';
		   }

		if (!empty($data->cardiovascularswitch) && $data->cardiovascularswitch=='1' ){ 
			$cardiovascular_per_total = ($data->cardiovascular_per * 100) / TOTAL_CARDIO;
		  }else {
			 $cardiovascular_per_total = '0';
		   }

		if (!empty($data->examinationswitch) && $data->examinationswitch=='1' ){ 
			$examination_per_total = ($data->examination_per * 100) / TOTAL_EXAMINATION;
		  }else {
			 $examination_per_total = '0';
		  }             

		                 $infolist = student_info1($data->student_id,$test_id);
			             $class=$data->class;
			             $division=$data->division;
			             $roll_no=$data->roll_no;  
				           if(!empty($infolist)){
				              if(!empty($infolist['class']))$class=class_name($infolist['class']);				                   
				              if(!empty($infolist['division']))$division=$infolist['division'];				                   
				              if(!empty($infolist['roll_no']))$roll_no=$infolist['roll_no'];
				                          
				           }
		  
						$data1['order_csv'][$i] = array(
								'#S.No.' => $i,
								'Student Name' => $data->student_name,
								'Class' 				=> $class,

								'Division' 				=> $division,
								'Roll No' 				=> $roll_no,
								'Student Id' 			=> $data->school_prefix . '-' . $data->unique_id,
								'Date of Birth' 		=> $data->date_of_birth,
								'Gender' 				=> $data->gender,
								'Parent Mobile' 		=> $data->parent_mobile,
								'Screeing Date' 		=> $data->created,
								'Weight/ KGS' 			=> $weight,
								'Height/ CMS' 			=> $height,
								'BMI' 					=> $bmi,
								'BMI Percentile Status' => $bmi_status,
								'Biometric %'           => $general_per_total,
								'Right Eye Sphere' 		=> $right_sp,
								'Right Eye Cylindrical' => $right_cy,
								'Right Eye Axis IN' 	=> $right_axis,
								'Right EyePupil Size' 	=> $right_pupil_size,
								'Right Eye Spherical Equivalent' => $right_se,
								'Left Eye Sphere' 		=> $left_sp,
								'Left Eye Cylindrical'  => $left_cy,
								'Left Eye Axis IN' 		=> $left_axis,
								'Left EyePupil Size' 	=> $left_pupil_size,
								'Left Eye Spherical Equivalent' => $left_se,
								'Screeing Result' 		=> $screeing_result,
								'Myopia' 				=> $myopia,
								'Hyperopia' 			=> $hyperopia,
								'Astigmatism' 			=> $astigmatism,
								'Anisometropia' 		=> $anisometropia,
								'Strabismus' 			=> $strabismus,
								'Anisocoria' 			=> $anisocoria,
								'Eye %'                 => $eye_per_total,
								'Ear Wax' 				=> $ear_wax,
								'Ear Drum' 				=> $ear_drum,
								'Ear' 					=> $ear,
								'Nosal Track' 			=> $nosal_track,
								'Nose' 					=> $nose,
								'Tonsils' 				=> $tonsils,
								'Throat' 				=> $throat,
								'ENT %'                 => $ent_per_total,
								'Pulse' 				=> $pulse,
								'Pulse Status' 			=> $pulse_status,
								'Spirometry' 			=> $spirometry,
								'Spirometry Status' 	=> $spirometry_status,
								'Respiratory Rate' 		=> $respiratory,
								'Resporatory Rate Status' => $resporatory_status,
								'Oximetry' 				=> $oximetry,
								'Oximetry Status' 		=> $oximetry_status,
								'Heart Sound' 			=> $mummur,
								'Lung Sound' 			=> $auscultation,
								'Cardiovascular %'      => $cardiovascular_per_total,
								'Image 1'				=> $image1 ,
								'Image 2' 				=> $image2 ,
								'Gum Inflammation' 		=> $gum_info,
								'Sensitivity' 			=> $sensitivity,
								'Bleeding' 				=> $bleeding,
								'Filling In Teeth' 		=> $filling,
								'Caries' 				=> $caries,
								'Alignment Of Teeth' 	=> $alignment,
								'Bad Odour' 			=> $bad_odor,
								'Plaque' 				=> $plaque,
								'Dental %'				=> $dental_per_total,
								'Palor' 				=> $palor,
								'Lymphadenopathy' 		=> $lymphadenopathy,
								'Edema' 				=> $edema,
								'Skin' 					=> $skin,
								'Cyanosis' 				=> $cyanosis,
								'Icterus' 				=> $icterus,
								'Allergy' 				=> $allergy,
								'Stomach Ache' 			=> $stomach_ache,
								'CNS Parameter' 		=> $cns,
								'Nail Hygiene' 			=> $nail,
								'Hair Hygiene' 			=> $hair,
								'Examination %' 		=> $examination_per_total,
					);


    				$color_code=$color[$code];
					 	$code++;
					 	if($code==2)
							$code=0;
				 		$this->excel->getActiveSheet()->getStyle('A'.($i+1).':BW'.($i+1).'')->applyFromArray($styleArray);

					 	 $this->excel->getActiveSheet()->getStyle('A'.($i+1).':BW'.($i+1))->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB($color_code); 

					$i++;

				}

		$this->excel->getActiveSheet()->setTitle('All student information');

		// To set password for sheet

		$this->excel->getActiveSheet()->getProtection()->setPassword('urstorecommissionexcel');

		// To make sheet protected

		$this->excel->getActiveSheet()->getProtection()->setSheet(false);


		$letters = range('1','100');  

		$count =0;

		$cell_name="";

		$color_code2= '#DDDDDDDD';

		$this->excel->getActiveSheet()->getStyle(1)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB($color_code2); 

	//	$this->excel->getActiveSheet()->getStyle(1)->getFont()->setBold(true);

			$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);

	

	//	$this->excel->getActiveSheet()->getColumnDimension('BO')->setWidth(25);

		foreach(range('A','Z') as $columnID)

		{

			$this->excel->getActiveSheet()->getColumnDimension($columnID)->setWidth(15);

		}

		// foreach(range('H','Z') as $columnID)

		// {

		// 	$this->excel->getActiveSheet()->getColumnDimension($columnID)->setWidth(20);

			

		// }

		foreach(range('B','BW') as $columnID)

		{

			$this->excel->getActiveSheet()->getColumnDimension($columnID)->setWidth(35);

	
		}

		$styleArray = array(

		  'borders' => array(

			'allborders' => array(

			  'style' => PHPExcel_Style_Border::BORDER_THIN

			)

		  ),

		  'alignment' => array(

            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,

			)

		);

		$border_end = 1000;

		for($k=1;$k<=$border_end;$k++)

		{			

			$this->excel->getActiveSheet()->getStyle('A'.$k.':BW'.$k.'')->applyFromArray($styleArray);

		}

		for($k=$border_end+6;$k<=$i;$k++)

		{			

			$this->excel->getActiveSheet()->getStyle('I'.$k.':BW'.$k.'')->applyFromArray($styleArray);

		}

		

		unset($styleArray);

		$this->excel->getActiveSheet()->fromArray($data1['order_csv']);

		// file name for download

		$filename = $filename.".xls"; 

		header("Content-Type: application/vnd.ms-excel");
		header("Content-Disposition: attachment; filename=\"$filename\"");
		header('Cache-Control: max-age=0'); //no cache

		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');

		//$objWriter->save('php://output');
      $objWriter->save('assets/uploads/school_report/'.$filename);
		header("Location: ".base_url().'assets/uploads/school_report/'.$filename);
exit();
//exit();
		$objWriter->close();



 }



public function generateDemoCSV() { 
      $this->_check_login();
      $test_id=$this->input->get('test_id');
      if(empty($test_id)){
      	 $this->session->set_flashdata('msg_error','Test Id is empty');
      	 redirect($_SERVER['HTTP_REFERER']);
      }
     $result=$this->superadmin_model->student_test_export();

    
    if(!empty($result)){
      
        $this->load->library('excel');
        //activate worksheet number 1
        $this->excel->setActiveSheetIndex(0);
        //name the worksheet
        $letters   = range('A', 'Z');
        array_push($letters,"AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ","BA","BB","BC","BD","BE","BF","BG","BH","BI","BJ","BK","BL","BM","BN","BO","BP","BQ","BR","BS","BT","BU");
        $this->excel->getActiveSheet()->setTitle('Student Information');   
    // Create new PHPExcel object
    
        $hedare = array("S.No","Name","Class","Student Id","Unique Id"); 
       //$hedare = array("S.No","Name","Class","Student Table Id","Student Id"); 
//interchanging names- student id is unique id and student test id is student id
        //Biometric
        $hedare[] = 'Biometric Switch';
        $hedare[] =  'Weight/KGS';
        $hedare[] =  'Height/CMS';
        $hedare[] =  'BMI';
        $hedare[] =  'BMI Percentile';
        $hedare[] =  'Notes';        

        //Eye Examination
        //Right Eye
        $hedare[] ='Eye Switch';
        $hedare[] ='Sphere/dpt';
        $hedare[] = 'Cylindrical/dpt'; 
        $hedare[] = 'Axis IN/dec'; 
        $hedare[] = 'Pupil Size/mm'; 
        $hedare[] = 'Spherical Equivalent/dpt';
 
        //left Eye
        $hedare[] ='Sphere/dpt';
        $hedare[] = 'Cylindrical/dpt'; 
        $hedare[] = 'Axis IN/dec'; 
        $hedare[] = 'Pupil Size/mm'; 
        $hedare[] = 'Spherical Equivalent/dpt';

        $hedare[] ='Myopia';
        $hedare[] = 'Anisometropia'; 
        $hedare[] = 'Hyperopia'; 
        $hedare[] = 'Strabismus'; 
        $hedare[] = 'Astigmatism';
        $hedare[] = 'Anisocoria';
        /*$hedare[] = 'Screeing Result'; */
        $hedare[] = 'Notes'; 

       //DENTAL SCREENING 
        $hedare[] = 'Dental Switch';
        $hedare[] = 'Gum Inflammation';
        $hedare[] = 'Sensitivity'; 
        $hedare[] = 'Bleeding'; 
        $hedare[] = 'Filling In Teeth';
        $hedare[] = 'Caries Gen'; 
        $hedare[] = 'Caries P/AB';
        $hedare[] = 'Caries';
        $hedare[] = 'Alignment Of Teeth'; 
        $hedare[] = 'Bad Odour';
        $hedare[] = 'Plaque';  
        $hedare[] = 'Notes';   
       
       //Ear 
        $hedare[] = 'Ear Switch';
        $hedare[] = 'Ear - Wax';
        $hedare[] = 'Nasal Track'; 
        $hedare[] = 'Tonsils'; 
        $hedare[] = 'Ear - Drum'; 
        $hedare[] = 'Notes'; 

       //Cardiovascular and Respiratory 
        $hedare[] = 'Cardio Switch';
        $hedare[] = 'Pulse(Beats / Min)';
        $hedare[] = 'Pulse Status';
        $hedare[] = 'Blood Pressure'; 
        $hedare[] = 'Blood Pressure Status'; 
        $hedare[] = 'Respiratory Rate(IN %)';
        $hedare[] = 'Respiratory Status';
        $hedare[] = 'Oximetry(IN %)'; 
        $hedare[] = 'Oximetry Status'; 
        $hedare[] = 'Heart Sound'; 
        $hedare[] = 'Lung Sound';
        $hedare[] = 'Notes'; 

        //General Examination  
        $hedare[] = 'Examination Switch';
        $hedare[] = 'Palor';
        $hedare[] = 'Lymphadenopathy'; 
        $hedare[] = 'Edema'; 
        $hedare[] = 'Skin'; 
        $hedare[] = 'Cyanosis'; 
        $hedare[] = 'Icterus';
        $hedare[] = 'Allergy';
        $hedare[] = 'Stomach Ache'; 
        $hedare[] = 'CNS Parameter'; 
        $hedare[] = 'Nail Hygiene'; 
        $hedare[] = 'Hair Hygiene'; 
        $hedare[] = 'Notes'; 
        // echo count($letters).'<br>';echo  count($hedare);die;

        $data=array();
       // $data[]=array();
        $count_row=2; // for single product drop down manage
        //$count_row++; 
        $var=3;      // variation product drop down
       // $color_row=2;
              
        $serial_num=1;
        foreach($result as $row){	 
        	$count_row++;
        	$col_val=array();
        	//  $var++;
        // $color_row ++;
         // $key=0;
         // $i = $key+1;
        // $this->excel->getActiveSheet()->getStyle($letters[count($col_val)-1] . $color_row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ff4141');
        	  $infolist = student_info1($row->student_id,$test_id);
              $class=$row->class;
             // $division=$row->division;
             /// $roll_no=$row->roll_no;  
	           if(!empty($infolist)){
	              if(!empty($infolist['class']))$class=class_name($infolist['class']);
	                   
	              //if(!empty($infolist['division']))$division=$infolist['division'];                
	             // if(!empty($infolist['roll_no']))$roll_no=$infolist['roll_no'];
	                          
	           }
        
          $col_val[]  = $serial_num; $serial_num++;
          $col_val[]  = $row->student_name;
          $col_val[]  = $class;
          $col_val[]  = $row->student_id;
		  $col_val[]  = $row->school_prefix.'-'.$row->unique_id;

         if($row->generalswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
         // $col_val[]  = $row->generalswitch;
         
         
         for($i=1;$i<=2;$i++){

          $cell_name   = $letters[count($col_val)-1] . $count_row;
          
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          if($i==1)$objValidation->setFormula1('"On,Off"'); 
          if($i==2)$objValidation->setFormula1('"Under Weight,Normal,Over Weight,Obese"'); 

         if($i==1){
		          if($row->generalswitch==1 && !empty($row->general)){
					  $general=json_decode($row->general);
					   $col_val[]  = $general->weight;
		               $col_val[]  = $general->height;
		               $col_val[]  = $general->bmi;
					   $col_val[]  = $general->bmi_status;
				  }else{
					  $col_val[]  = '';
					  $col_val[]  = '';
					  $col_val[]  = '';
					  $col_val[]  = '';
				  }
		      }


          }
           $col_val[]  = $row->general_notes;


          //Eye
          //Right Eye
           $val=array();
           // not working after 3.75 values, maybe have limit for dropdown values
          /*for($i=-7.25;$i<=3.75;$i +=0.25){ 
          	if($i>0)$val[]='+'.$i;
              else $val[]=$i;
          }
          $eye_values='"'.implode(',',$val).'"';*/
         
         //right eye sphere & cylindrical
          if($row->eyeswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
         //  $col_val[]  = $row->eyeswitch;
           $cell_name   = $letters[count($col_val)-1] . $count_row;
          
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          $objValidation->setFormula1('"On,Off"'); 
           $eye='';

		if($row->eyeswitch==1 && !empty($row->eye)){
                
                $eye=json_decode($row->eye);
                $col_val[]= $eye->right_sp;
                $col_val[]= $eye->right_cy;
                $col_val[]= $eye->right_axis;
	            $col_val[]= $eye->right_pupil_size;
				$col_val[]= $eye->right_se;
                $col_val[]= $eye->left_sp;
                $col_val[]= $eye->left_cy;
				$col_val[]= $eye->left_axis;
	            $col_val[]= $eye->left_pupil_size;
                $col_val[]= $eye->left_se;
                
           	} else {
				$col_val[]  = '0.00';
				$col_val[]  = '0.00';
				$col_val[]  = '';
				$col_val[]  = '';
				$col_val[]  = '0.00';
				$col_val[]  = '0.00';
				$col_val[]  = '0.00';
				$col_val[]  = '';
				$col_val[]  = '';
				$col_val[]  = '0.00';
			}
         
        //myopia etc
        for($i=1;$i<=6;$i++){
         
        	if($row->eyeswitch==1 && !empty($row->eye)){               
               // $eye=json_decode($row->eye);
                if($i==1)$col_val[]= $this->replace_p_ab_op($eye->myopia);
                if($i==2)$col_val[]= $this->replace_p_ab_op($eye->anisometropia);
                if($i==3)$col_val[]= $this->replace_p_ab_op($eye->hyperopia);
                if($i==4)$col_val[]= $this->replace_p_ab_op($eye->strabismus);   
                if($i==5)$col_val[]= $this->replace_p_ab_op($eye->astigmatism);                
                if($i==6)$col_val[]= $this->replace_p_ab_op($eye->anisocoria);
                //if($i==7)$col_val[]= $eye->screeing_result;
               
           	} else {
				if($i==1)$col_val[]= 'Absent';
                if($i==2)$col_val[]= 'Absent';
                if($i==3)$col_val[]= 'Absent';
                if($i==4)$col_val[]= 'Absent';   
                if($i==5)$col_val[]= 'Absent';                
                if($i==6)$col_val[]= 'Absent';
                //if($i==7)$col_val[]= 'Normal Vision';
			}
        
          $cell_name   = $letters[count($col_val)-1] . $count_row;
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          //if($i!=7)
              $objValidation->setFormula1('"Present,Absent"');
          //else $objValidation->setFormula1('"Normal Vision,Abnormal Vision"');
          }


          $col_val[]  = $row->eye_notes;

        //Dental
         // $col_val[]  = $row->dentalswitch;
          if($row->dentalswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
          $cell_name   = $letters[count($col_val)-1] . $count_row;          
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          $objValidation->setFormula1('"On,Off"'); 
          
               if($row->dentalswitch==1 && !empty($row->dental)){
				   $dental=json_decode($row->dental);
			   }else $dental='';
         for($i=1;$i<=9;$i++){
          
            if($row->dentalswitch==1 && !empty($row->dental)){
               
                //$dental=json_decode($row->dental);
                if($i==1)$col_val[]= $this->replace_p_ab_op($dental->gum_info);
                if($i==2)$col_val[]= $this->replace_p_ab_op($dental->sensitivity);
                if($i==3)$col_val[]= $this->replace_p_ab_op($dental->bleeding);
                if($i==4)$col_val[]= $this->replace_p_ab_op($dental->filling);   
                if(isset($dental->stage)){
					if($dental->stage=='A')$stage='Adult';
					else if($dental->stage=='C')$stage='Child';else $stage='';
				}else $stage='';  
				if($dental->alignment=='N')$align='Normal';
				    else if($dental->alignment=='ABN')$align='Abnormal'; 
					else $align='';
					
                if($i==5)$col_val[]= $stage;                
                if($i==6)$col_val[]= $this->replace_p_ab_op($dental->caries);
                if($i==7)$col_val[]= $align;
                if($i==8)$col_val[]= $this->replace_p_ab_op($dental->bad_odor);
                if($i==9)$col_val[]= $this->replace_p_ab_op($dental->plaque);
               
            } else {
				if($i==1)$col_val[]= 'Absent';
                if($i==2)$col_val[]= 'Absent';
                if($i==3)$col_val[]= 'Absent';
                if($i==4)$col_val[]= 'Absent';  
                 
                if($i==5)$col_val[]= 'Child';                
                if($i==6)$col_val[]= 'Absent';
                if($i==7)$col_val[]= 'Normal';
                if($i==8)$col_val[]= 'Absent';
                if($i==9)$col_val[]= 'Absent';
			}
			//condition on off in query basis
          $cell_name   = $letters[count($col_val)-1] . $count_row;
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          if($i<=4 || $i==6 ||$i==8 ||$i==9)
              $objValidation->setFormula1('"Present,Absent"');
          if($i==5)
             $objValidation->setFormula1('"Adult,Child"');
         if($i==7)
             $objValidation->setFormula1('"Normal,Abnormal"');//N,ABN

              if($i==6){
                   if($row->dentalswitch==1 && !empty($row->scal) && ($row->scal!=null) && $row->scal!='null'){

                     $scal=json_decode($row->scal,true);
                     $col_val[]=implode(',',$scal);
                   	// $col_val[]=$row->scal;
                  
                   }else{
                     $col_val[]  = '';
                   }
              }   
          }
        $col_val[]  = $row->dental_notes;

          //ENT
         // $col_val[]  = $row->entswitch;
          if($row->entswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
        
           $cell_name   = $letters[count($col_val)-1] . $count_row;         
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          $objValidation->setFormula1('"On,Off"'); 
        
          	if($row->entswitch==1 && !empty($row->ent)){
                //if($i==1)$col_val[]=$row->
                $ent=json_decode($row->ent);
			}else $ent='';

           for($i=1;$i<=4;$i++){
          //$col_val[]  = 'P';
           	if($row->entswitch==1 && !empty($row->ent)){
                //if($i==1)$col_val[]=$row->
               // $ent=json_decode($row->ent);
                if($i==1)$col_val[]= $ent->ear_wax;
                if($i==2)$col_val[]= $ent->nosal_track;
                if($i==3)$col_val[]= $ent->tonsils;
                if($i==4)$col_val[]= $ent->ear_drum;   
                
               
           	} else {
				if($i==1)$col_val[]= 'Absent';
                if($i==2)$col_val[]= 'Normal';
                if($i==3)$col_val[]= 'Absent';
                if($i==4)$col_val[]= 'Normal';   
             
			}//condition on off in query basis
          $cell_name   = $letters[count($col_val)-1] . $count_row;
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          if($i==1 || $i==3)
              $objValidation->setFormula1('"Present,Absent"');
          if($i==2 || $i==4)
             $objValidation->setFormula1('"Normal,Abnormal"');
         //if($i==5 || $i==6 || $i ==7)
            // $objValidation->setFormula1('"Good,Bad"');
          }
        $col_val[]  = $row->ent_notes;                   

        
        //Cardiovascular
          //$col_val[]  = $row->cardiovascularswitch;
          if($row->cardiovascularswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
        
           $cell_name   = $letters[count($col_val)-1] . $count_row;
          
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          $objValidation->setFormula1('"On,Off"'); 


            if($row->cardiovascularswitch==1 && !empty($row->cardiovascular)){
                //if($i==1)$col_val[]=$row->
                $cardio=json_decode($row->cardiovascular);
			}else $cardio='';
           for($i=1;$i<=6;$i++){
          //$col_val[]  = 'P';
          if($row->cardiovascularswitch==1 && !empty($row->cardiovascular)){
                //if($i==1)$col_val[]=$row->
                //$cardio=json_decode($row->cardiovascular);
                if($i==1){
                	$col_val[]= $cardio->pulse;
                    $col_val[]= $this->replace_p_b($cardio->pulse_status);
                }
                if($i==2){
                	$col_val[]= $cardio->spirometry;
                    $col_val[]= $this->replace_p_b($cardio->spirometry_status);
                 }
                if($i==3){
	                $col_val[]= $cardio->respiratory;   
	                $col_val[]= $this->replace_p_b($cardio->resporatory_status);
                }           
                if($i==4){
                	$col_val[]= $cardio->oximetry;
                    $col_val[]= $this->replace_p_b($cardio->oximetry_status);
                 }
                if($i==5)$col_val[]= $this->replace_p_b($cardio->mummur);
                if($i==6)$col_val[]= $this->replace_p_b($cardio->auscultation);
              
               
           	} else {
				if($i<=4){$col_val[]  = '';$col_val[]  = 'Good';}
				else $col_val[]  = 'Normal';
				
			}//condition on off in query basis
          $cell_name   = $letters[count($col_val)-1] . $count_row;

                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          if($i<=4)
              $objValidation->setFormula1('"Good,Bad,N/A"');
          if($i==5 || $i==6)
             $objValidation->setFormula1('"Normal,Abnormal,N/A"');//N,ABN,N/A
          }
         // if(empty($row->cardiovascularswitch) || empty($row->cardiovascular)){
          	//$col_val[]  = '';$col_val[]  = '';$col_val[]  = '';$col_val[]  = '';
          //}
            $col_val[]  = $row->cardiovascular_notes;

         //General Examination
         // $col_val[]  = $row->examinationswitch;
          if($row->examinationswitch==1)$col_val[]  = 'On'; else $col_val[]  = 'Off';
         //  $col_val[]  = $row->eyeswitch;
           $cell_name   = $letters[count($col_val)-1] . $count_row;
          
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          $objValidation->setFormula1('"On,Off"'); 

           
		    if($row->examinationswitch==1 && !empty($row->examination)){
                //if($i==1)$col_val[]=$row->
                $examination=json_decode($row->examination);
			}else $examination='';

           for($i=1;$i<=11;$i++){
          //$col_val[]  = 'P';
          if($row->examinationswitch==1 && !empty($row->examination)){
                //if($i==1)$col_val[]=$row->
                //$examination=json_decode($row->examination);
                if($i==1)$col_val[]= !empty($examination->palor)? $examination->palor:'';
				if($i==2)$col_val[]= !empty($examination->lymphadenopathy)? $examination->lymphadenopathy:'';
				if($i==3)$col_val[]= !empty($examination->edema)?$examination->edema:'';
				if($i==4)$col_val[]= !empty($examination->skin)? $examination->skin:'';
				if($i==5)$col_val[]= !empty($examination->cyanosis)? $examination->cyanosis:'';
				if($i==6)$col_val[]= !empty($examination->icterus)? $examination->icterus:'';
				if($i==7)$col_val[]= !empty($examination->allergy)?$examination->allergy:'';
				if($i==8)$col_val[]=  !empty($examination->stomach_ache)?$examination->stomach_ache:'';
				if($i==9)$col_val[]=  !empty($examination->cns)? $examination->cns:'';
				if($i==10)$col_val[]= !empty($examination->nail)? $examination->nail:'';
				if($i==11)$col_val[]= !empty($examination->hair) ? $examination->hair:'';

               
           	} else {
				if($i==1)$col_val[]= 'Absent';
				if($i==2)$col_val[]= 'Absent';
				if($i==3)$col_val[]= 'Absent';

				if($i==4)$col_val[]= 'Normal';
				if($i==5)$col_val[]= 'Absent';
				if($i==6)$col_val[]= 'Absent';

				if($i==7)$col_val[]= 'Absent';
				if($i==8)$col_val[]= 'Absent';
				if($i==9)$col_val[]= 'Normal';

				if($i==10)$col_val[]= 'Good';
				if($i==11)$col_val[]= 'Good';
				
			}//condition on off in query basis
          $cell_name   = $letters[count($col_val)-1] . $count_row;
                
          $objValidation = $this->excel->getActiveSheet()->getCell($cell_name)->getDataValidation();
          $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
          $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
          $objValidation->setAllowBlank(false);
          $objValidation->setShowInputMessage(true);
          $objValidation->setShowErrorMessage(true);
          $objValidation->setShowDropDown(true);
          $objValidation->setErrorTitle('Input error');
          $objValidation->setPrompt('Please pick a value from the drop-down list.');
          if($i==1||$i==2||$i==3||$i==5||$i==6||$i==7||$i==8)
              $objValidation->setFormula1('"Present,Absent"');
          if($i==4 || $i==9)
             $objValidation->setFormula1('"Normal,Abnormal"');
          if($i==10 || $i==11)
             $objValidation->setFormula1('"Good,Bad"');
          }
         $col_val[]  = $row->examination_notes;
        // $col_val[]  = $row->final_notes;         
         $data[]=$col_val;
           $var++;
         
          }
 
    
        
        $this->excel->getActiveSheet()->getStyle('A1','B1')->getFont()->setBold(true);
       
        //change the font size
        $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
        $this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        
        $count     = 0;
        $cell_name = "";
        //First Heading of merge
       
      

        foreach ($hedare as $tittle) {
            
            //p($letters[$count]); //die;
            $cell_name   = (isset($letters[$count]) && !empty($letters[$count])) ? $letters[$count]."1" : "A1";
			$cell_name2   = (isset($letters[$count]) && !empty($letters[$count])) ? $letters[$count]."2" : "A2";
            $column_name = (isset($letters[$count]) && !empty($letters[$count])) ? $letters[$count] : "A";
            $count++;
            $value = $tittle;
            //$objPHPExcel->getActiveSheet()->SetCellValue($cell_name, $value);
            // Make bold cells
         
            $this->excel->getActiveSheet()->getStyle($cell_name)->getFont()->setBold(true);
            $this->excel->getActiveSheet()->getStyle($cell_name)->getFont()->setSize(12);
            $this->excel->getActiveSheet()->getColumnDimension($column_name)->setWidth(15);
            //$this->excel->getActiveSheet()->getStyle($cell_name)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('ff6531');
			$this->excel->getActiveSheet()->getStyle($cell_name2)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('f5cf8e');
          
             
            if ($count > 1) {
                // To set the column of the sheet editable ex: all I and J column are editable here 
            $this->excel->getActiveSheet()->getStyle("I$count:J$count")->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);
            }
        }
		$this->excel->getActiveSheet()->getStyle('A:BY')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
		 $this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
		
        $arr=array('J','K','AC','AD','AL','AP','AY','BK','BX','BZ');
        foreach($arr as $col){
            $this->excel->getActiveSheet()->getColumnDimension($col)->setWidth(18);
        }
        $arr=array('BJ','BH','AZ','BA','BB','AE','V','Q');
        foreach($arr as $col){
            $this->excel->getActiveSheet()->getColumnDimension($col)->setWidth(22);
        }
           
	   $this->excel->getActiveSheet()->mergeCells("A1:E1");
	   $this->excel->getActiveSheet()->setCellValue('A1','Basic Student Info');
	   $this->excel->getActiveSheet()->getStyle("A1:E1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("A1:E1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('d6e9fe');
	   
	   $this->excel->getActiveSheet()->mergeCells("F1:K1");
	   $this->excel->getActiveSheet()->setCellValue('F1','Biometric');
	   $this->excel->getActiveSheet()->getStyle("F1:K1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("F1:K1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('b2d6ff');
	   
	   $this->excel->getActiveSheet()->mergeCells("L1:AC1");
	   $this->excel->getActiveSheet()->setCellValue('L1','Eye');
	   $this->excel->getActiveSheet()->getStyle("L1:AC1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("L1:AC1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('d6e9fe');
	   
	   $this->excel->getActiveSheet()->mergeCells("AD1:AO1");
	   $this->excel->getActiveSheet()->setCellValue('AD1','Dental');
	   $this->excel->getActiveSheet()->getStyle("AD1:AO1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("AD1:AO1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('b2d6ff');

	   
	  $this->excel->getActiveSheet()->mergeCells("AP1:AU1");
	  $this->excel->getActiveSheet()->setCellValue('AP1','Ear');
	   $this->excel->getActiveSheet()->getStyle("AP1:AU1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("AP1:AU1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('d6e9fe');
	   
	   $this->excel->getActiveSheet()->mergeCells("AV1:BG1");
	   $this->excel->getActiveSheet()->setCellValue('AV1','Cardiovascular');
	   $this->excel->getActiveSheet()->getStyle("AV1:BG1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("AV1:BG1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('b2d6ff');
	   
	   $this->excel->getActiveSheet()->mergeCells("BH1:BT1");
	   $this->excel->getActiveSheet()->setCellValue('BH1','Examination');
	   $this->excel->getActiveSheet()->getStyle("BH1:BT1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   $this->excel->getActiveSheet()->getStyle("BH1:BT1")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('d6e9fe');


	    $arr=array('E','K','AC','AO','AU','BG','BT');
         $border_col = count($result)+2;
        foreach($arr as $col){
            $this->excel->getActiveSheet()->getColumnDimension($col)->setWidth(16);

             $a=$col.'1';$b=$col.$border_col;
           
            $this->excel->getActiveSheet()->getStyle("$a:$b")->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

            

        }

       for($i=1;$i<=count($result)+2;$i++){           
         
              $this->excel->getActiveSheet()->getRowDimension($i)->setRowHeight(23);      

        }
	  
     
		$first_header=array();		   
        array_unshift($data,$hedare);
		array_unshift($data,$first_header);
		


        $this->excel->getActiveSheet()->fromArray($data);
        // read data to active sheet
   // }           
        // file name for download
		if(isset($_GET) && $_GET['school_name']!='')
			    $school_name='-'.$_GET['school_name'];
		else $school_name='';
		
        $filename = "EHR" . $school_name.'-'.date('Y-m-d H:i:s') . ".xls";       
        header("Content-Type: application/vnd.ms-excel");
        //$filename = "EHR-" . date('Y-m-d') . ".csv";       
        //header("Content-Type: application/csv");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header('Cache-Control: max-age=0'); //no cache      
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
        //force user to download the Excel file without writing it to server's HD
        $objWriter->save('php://output');
  }  else {
	  $this->session->set_flashdata('msg_error','No students found');
    	redirect($_SERVER['HTTP_REFERER']);

  }	  
}



function ajax_export_student_info($id=''){
 
  $result=$this->superadmin_model->class_by_schoolid($id);
  $class_detail='<option value="">All</option>';
  if(!empty($result)){
	  	foreach($result as $row){
	        $class_detail.='<option value="'.$row->class_name.'">'.$row->class_name.'</option>';
	  	}
  }
  
  $test_list='<option value="">Select</option>';
  $result=$this->common_model->get_result('test',array('school_id'=>$id),'',array('test_id','DESC'));
  if(!empty($result)){
	  	 foreach($result as $row){
	        $test_list.='<option value="'.$row->test_id.'">'.ucwords($row->test_name).'</option>';
	  	}
  }
  $data=array('class_detail'=>$class_detail,'test_list'=>$test_list);
   echo json_encode($data);
}
function ajax_import_student_info($id=''){
  $result=$this->superadmin_model->find_doctors_by_schoolid($id);
  $doctor_list='<option value="">Select Doctor</option>';
  if(!empty($result)){
  	foreach($result as $row){
        $doctor_list.='<option value="'.$row->user_id.'">'.$row->full_name.'</option>';
  	}
  }
  $test_list='<option value="">Select</option>';
  $result=$this->common_model->get_result('test',array('school_id'=>$id),'',array('test_id','DESC'));
  if(!empty($result)){
	  	 foreach($result as $row){
	        $test_list.='<option value="'.$row->test_id.'">'.ucwords($row->test_name).'</option>';
	  	}
  }
  $data=array('doctor_list'=>$doctor_list,'test_list'=>$test_list);
   echo json_encode($data);
} 
 
 function ajax_test_list($id=''){
 
  $test_list='<option value="">Select</option>';
  $result=$this->common_model->get_result('test',array('school_id'=>$id),'',array('test_id','DESC'));
  if(!empty($result)){
	  	 foreach($result as $row){
	        $test_list.='<option value="'.$row->test_id.'">'.$row->test_name.'</option>';
	  	}
  }
 echo $test_list;
} 
 function edit_tests($school_id=''){

   if(isset($_POST['test_name']) && !empty($_POST['test_name'])){
   	   $data=array('test_name'=> $this->input->post('test_name'));
   	   $where = array('test_id'=>$this->input->post('test_id'));
   	   if($this->common_model->update('test',$data,$where)){
   	   	$this->session->set_flashdata('msg_success','Test updated successfully');
   	   	redirect('superadmin/schools');
   	   }
   }




 $data['school_data'] = $this->common_model->get_row('users',array('user_id'=>$school_id,'user_role'=>3));
 
  $data['tests']=$this->common_model->get_result('test',array('school_id'=>$school_id),'',array('test_id','DESC'));
  //$this->load->view('superadmin/edit_test',$data);
  $data['title']='Edit Tests';
  $data['template']='superadmin/edit_test';

	    $this->load->view('templates/superadmin/superadmin_template',$data);
 //echo json_encode($result);
} 


function readExcel($filepath='',$doctor_id='',$school_id='',$test_id='')
{       if(empty($filepath)){
	      $this->session->set_flashdata('msg_error', 'Not Uploaded or Incorrect Format');
          redirect($_SERVER['HTTP_REFERER']);
           }
		  
		$school_prefix=$this->superadmin_model->find_school_by_doctorid($doctor_id,$school_id);
           
		  
        $this->load->library('Csvimport');

        $hedare = array("sno","name","class","student_id","unique_id"); 

        //Biometric
        $hedare[] = 'generalswitch';
        $hedare[] = 'weight';
        $hedare[] = 'height';
        $hedare[] = 'bmi';
        $hedare[] = 'bmi_status';
        $hedare[] = 'general_notes';        

        //Eye Examination
        //Right Eye
        $hedare[] = 'eyeswitch';
        $hedare[] = 'right_sp';
        $hedare[] = 'right_cy'; 
        $hedare[] = 'right_axis'; 
        $hedare[] = 'right_pupil_size'; 
        $hedare[] = 'right_se';
 
        //left Eye
        $hedare[] = 'left_sp';
        $hedare[] = 'left_cy'; 
        $hedare[] = 'left_axis'; 
        $hedare[] = 'left_pupil_size'; 
        $hedare[] = 'left_se';

        $hedare[] = 'myopia';
        $hedare[] = 'anisometropia'; 
        $hedare[] = 'hyperopia'; 
        $hedare[] = 'strabismus'; 
        $hedare[] = 'astigmatism';
        $hedare[] = 'anisocoria';
        //$hedare[] = 'screeing_result'; 
        $hedare[] = 'eye_notes'; 
       
       //DENTAL SCREENING 
        $hedare[] = 'dentalswitch';
        $hedare[] = 'gum_info';
        $hedare[] = 'sensitivity'; 
        $hedare[] = 'bleeding'; 
        $hedare[] = 'filling';

        $hedare[] = 'stage'; //A/C
        $hedare[] = 'caries'; //P/AB

        $hedare[] = 'scal';//scal
        $hedare[] = 'alignment'; 
        $hedare[] = 'bad_odor';
        $hedare[] = 'plaque';  
        $hedare[] = 'dental_notes';   
      
       //Ear 
        $hedare[] = 'entswitch';
        $hedare[] = 'ear_wax';
        $hedare[] = 'nosal_track'; 
        $hedare[] = 'tonsils'; 
        $hedare[] = 'ear_drum'; 
        $hedare[] = 'ent_notes'; 

       //Cardiovascular and Respiratory 
        $hedare[] = 'cardiovascularswitch';
        $hedare[] = 'pulse';
        $hedare[] = 'pulse_status';
        $hedare[] = 'spirometry'; 
        $hedare[] = 'spirometry_status'; 
        $hedare[] = 'respiratory';
        $hedare[] = 'resporatory_status';
        $hedare[] = 'oximetry'; 
        $hedare[] = 'oximetry_status'; 
        $hedare[] = 'mummur'; 
        $hedare[] = 'auscultation';
        $hedare[] = 'cardiovascular_notes'; 

        //General Examination  
        $hedare[] = 'examinationswitch';
        $hedare[] = 'palor';
        $hedare[] = 'lymphadenopathy'; 
        $hedare[] = 'edema'; 
        $hedare[] = 'skin'; 
        $hedare[] = 'cyanosis'; 
        $hedare[] = 'icterus';
        $hedare[] = 'allergy';
        $hedare[] = 'stomach_ache'; 
        $hedare[] = 'cns'; 
        $hedare[] = 'nail'; 
        $hedare[] = 'hair'; 
        $hedare[] = 'examination_notes'; 
       
       // $result =   $this->csvimport->get_array('test.csv',$hedare);
	   $result =   $this->csvimport->get_array($filepath,$hedare);

        $data['csvData'] =  $result;
        unset($result[0]);
		//unset($result[1]);
        $x=array(); $error=array();$i=3;

       foreach($result as $row){
         if(!empty(array_filter($row)))$x[]=$row;
        

	           if(!is_numeric($row['weight']) && !empty($row['weight']))
	            {
	                $error[] = 'row number : ' . $i . ' weight is not numeric';
	            }
	            if(!is_numeric($row['height']) && !empty($row['height']))
	            {
	                $error[] = 'row number : ' . $i . ' height is not numeric';
	            }
	            if(!is_numeric($row['bmi']) && !empty($row['bmi']))
	            {
	                $error[] = 'row number : ' . $i . ' BMI is not numeric';
	            }
                //Eye
	            if(!is_numeric($row['right_sp']) && !empty($row['right_sp']))
	            {
	                $error[] = 'row number : ' . $i . ' Right Eye Sphere is not numeric';
	            }
	             if(!is_numeric($row['right_cy']) && !empty($row['right_cy']))
	            {
	                $error[] = 'row number : ' . $i . ' Right Eye Cylindrical is not numeric';
	            }
	             if(!is_numeric($row['right_axis']) && !empty($row['right_axis']))
	            {
	                $error[] = 'row number : ' . $i . ' Right Eye Axis is not numeric';
	            }
	             if(!is_numeric($row['right_pupil_size']) && !empty($row['right_pupil_size']))
	            {
	                $error[] = 'row number : ' . $i . ' Right Eye Pupil Size is not numeric';
	            }
	             if(!is_numeric($row['right_se']) && !empty($row['right_se']))
	            {
	                $error[] = 'row number : ' . $i . ' Right Eye Spherical Equivalent is not numeric';
	            }

	             if(!is_numeric($row['left_sp']) && !empty($row['left_sp']))
	            {
	                $error[] = 'row number : ' . $i . ' Left Eye Sphere is not numeric';
	            }
	             if(!is_numeric($row['left_cy']) && !empty($row['left_cy']))
	            {
	                $error[] = 'row number : ' . $i . ' Left Eye Cylindrical is not numeric';
	            }
	             if(!is_numeric($row['left_axis']) && !empty($row['left_axis']))
	            {
	                $error[] = 'row number : ' . $i . ' Left Eye Axis is not numeric';
	            }
	             if(!is_numeric($row['left_pupil_size']) && !empty($row['left_pupil_size']))
	            {
	                $error[] = 'row number : ' . $i . ' Left Eye Pupil Size is not numeric';
	            }
	             if(!is_numeric($row['left_se']) && !empty($row['left_se']))
	            {
	                $error[] = 'row number : ' . $i . ' Left Eye Spherical Equivalent is not numeric';
	            }
               
                //Cardio
                if(!is_numeric($row['pulse']) && !empty($row['pulse']))
	            {
	                $error[] = 'row number : ' . $i . ' Pulse is not numeric';
	            } 
				// if(!is_string($row['spirometry']) && !empty($row['spirometry']))
				 if(!empty($row['spirometry']) && $row['spirometry']!='N/A')
	            {   
			        if(!preg_match('#(\d+)(\/\d+)#',$row['spirometry']))
	                     $error[] = 'row number : ' . $i . ' Spirometry is not correct.It should be like a/b';
	            }
               				
				if(!empty($row['unique_id']))
	            {   $uid=explode('-',$row['unique_id']);
			             if($uid[0]!=$school_prefix)
	                $error[] = 'row number : ' . $i . ' Unique Id associated with school is not correct';
	            }               			
	          
	            $i++;
        }

                   if(!empty($error))
                    {
                        $errormsg = '';
                        foreach ($error as $err) {
                            $errormsg .= $err . '<br/>';
                        }

                        $this->session->set_flashdata('msg_error', 'Error occured in following rows</br>' . $errormsg . ' Please correct this and import again');

                       redirect($_SERVER['HTTP_REFERER']);

                    }

      
       foreach($x as $row){
		   
		 $general_notes=$eye_notes=$ent_notes=$dental_notes=$cardiovascular_notes=$examination_notes='';  
		if(strtolower($row['generalswitch']) == 'on')$generalswitch=1;else $generalswitch='';
        if(strtolower($row['entswitch']) == 'on')$entswitch=1;else $entswitch='';
        if(strtolower($row['eyeswitch']) == 'on')$eyeswitch=1;else $eyeswitch='';
        if(strtolower($row['dentalswitch']) == 'on')$dentalswitch=1;else $dentalswitch='';
        if(strtolower($row['cardiovascularswitch']) == 'on')$cardiovascularswitch=1;else $cardiovascularswitch='';
        if(strtolower($row['examinationswitch']) == 'on')$examinationswitch=1;else $examinationswitch='';
    
    if($generalswitch=='' && $entswitch=='' && $eyeswitch=='' && $dentalswitch=='' && $cardiovascularswitch=='' && $examinationswitch=='')continue;

       	 $general=$general_arr=array(
       	   	      "weight"   	   => $row['weight'],
       	   	      "height"  	   => $row['height'],
       	   	      "bmi"		       => $row['bmi'],
       	   	      "bmi_status"     => $row['bmi_status'], 
       	   	  );


         if(!empty(array_filter($general)) && !empty($generalswitch)){
         	     if(!empty($row['weight']) && !empty($row['height']) && empty($row['bmi'])){
                        $general['bmi']=number_format(($row['weight']/(($row['height']/100)*($row['height']/100))),2);
         	        }

         	        if(!empty($row['weight']) && !empty($row['height']) && empty($row['bmi_status'])){

                              if($general['bmi']<18.5){
						            $general['bmi_status'] = 'Under Weight';  
						        }else if($general['bmi']>18.5 && $general['bmi']<=24.9){
						            $general['bmi_status'] = 'Normal';  
						        }else if($general['bmi']>=25 && $general['bmi']<=29.9){
						            $general['bmi_status'] = 'Over Weight';  
						        }else if($general['bmi']>=30){
						            $general['bmi_status'] = 'Obese';  
						        }
         	        }
         	         $general_arr=$general;
         	         $general_per=count(array_filter($general));
         	         $general=json_encode($general);    
         	         $general_notes=$row['general_notes'];                
         	     }
         	     else {
         	     	$general='';
                    $general_per=''; 
         	     }


         if($row['ear_wax']=='Absent' && $row['ear_drum']=='Normal')$ear='good';
                 else $ear='bad';
         if($row['nosal_track']=='Normal')$nose='good';
                 else $nose='bad';
         if($row['tonsils']=='Absent')$throat='good';
                 else $throat='bad';


       	   $ent=$ent_arr=array(
       	   	      "ear_wax"   	 => $row['ear_wax'],
       	   	      "ear_drum"  	 => $row['ear_drum'],
       	   	      "ear"		  	 => $ear,
       	   	      "nosal_track"  => $row['nosal_track'],
       	   	      "nose"		 => $nose,
       	   	      "tonsils"		 => $row['tonsils'],
       	   	      "throat"		 => $throat
       	   	  );

       	   if(!empty(array_filter($ent)) && !empty($entswitch)){
       	   	          $ent_per=count(array_filter($ent));
       	   	          $ent=json_encode($ent); 
       	   	           $ent_notes=$row['ent_notes'];                          
       	       }
			   else {
			     	  $ent='';
			     	  $ent_per='';
			     }
            
       	   $eye=$eye_arr=array(
       	   	      "right_sp"   	 		=> $row['right_sp'],
       	   	      "right_cy"  	 		=> $row['right_cy'],
       	   	      "right_axis"		  	=> $row['right_axis'],
       	   	      "right_pupil_size"    => $row['right_pupil_size'],
       	   	      "right_se"		    => $row['right_se'],

       	   	      "left_sp"   	 		=> $row['left_sp'],
       	   	      "left_cy"  	 		=> $row['left_cy'],
       	   	      "left_axis"		  	=> $row['left_axis'],
       	   	      "left_pupil_size"     => $row['left_pupil_size'],
       	   	      "left_se"		        => $row['left_se'],

       	   	      "myopia"   	 		=> $this->replace_p_ab($row['myopia']),
       	   	      "hyperopia"  	 		=> $this->replace_p_ab($row['hyperopia']),
       	   	      "astigmatism"		  	=> $this->replace_p_ab($row['astigmatism']),
       	   	      "anisometropia"       => $this->replace_p_ab($row['anisometropia']),
       	   	      "strabismus"		    => $this->replace_p_ab($row['strabismus']),
       	   	      "anisocoria"          => $this->replace_p_ab($row['anisocoria']),
       	   	     // "screeing_result"		=> $row['screeing_result'],
       	   	      
       	   	  );

            if($eye['myopia']=='AB' && $eye['hyperopia']=='AB' && $eye['astigmatism']=='AB' && $eye['anisometropia']=='AB' && $eye['strabismus']=='AB' && $eye['anisocoria']=='AB' ){
            	       $eye['screeing_result']='Normal Vision';$eye_arr=$eye;
            	   }
            	else {
            	   	$eye['screeing_result']='Refer';$eye_arr=$eye;
            	   }
          
       	   if(!empty(array_filter($eye)) && !empty($eyeswitch)){
       	   	               $eye_per=count(array_filter($eye));
       	   	               $eye=json_encode($eye); 
       	   	                $eye_notes=$row['eye_notes'];        	   	               
       	   	           }
       	   	           else {
       	   	           	$eye='';
       	   	           	$eye_per='';
       	   	           }

       	    $cardiovascular=$cardiovascular_arr=array(
       	   	      "pulse"   	       => $row['pulse'],
       	   	      "pulse_status"  	   => $this->replace_p_b_op($row['pulse_status']),
       	   	      "spirometry"		   => $row['spirometry'],
       	   	      "spirometry_status"  => $this->replace_p_b_op($row['spirometry_status']),
       	   	      "respiratory"		   => $row['respiratory'],
       	   	      "resporatory_status" => $this->replace_p_b_op($row['resporatory_status']),
       	   	      "oximetry"		   => $row['oximetry'],
       	   	      "oximetry_status"	   => $this->replace_p_b_op($row['oximetry_status']),
       	   	      "mummur"		       => $this->replace_p_b_op($row['mummur']),
       	   	      "auscultation"	   => $this->replace_p_b_op($row['auscultation'])
       	   	  );
       	    if(!empty(array_filter($cardiovascular)) && !empty($cardiovascularswitch)){    	    	         
       	    	         $cardiovascular_per=count(array_filter($cardiovascular));
       	    	         $cardiovascular=json_encode($cardiovascular);
       	    	          $cardiovascular_notes=$row['cardiovascular_notes']; 
       	    	     }
       	    	     else {
       	    	     	$cardiovascular='';
       	    	     	$cardiovascular_per='';
       	    	     }

       	  $examination=$examination_arr=array(
		       	   	      "palor"   	       => $row['palor'],
		       	   	      "lymphadenopathy"    => $row['lymphadenopathy'],
		       	   	      "edema"		       => $row['edema'],
		       	   	      "skin"               => $row['skin'],
		       	   	      "cyanosis"		   => $row['cyanosis'],
		       	   	      "icterus"            => $row['icterus'],
		       	   	      "allergy"		       => $row['allergy'],
		       	   	      "stomach_ache"	   => $row['stomach_ache'],
		       	   	      "cns"		           => $row['cns'],
		       	   	      "nail"	           => $row['nail'],
		       	   	      "hair"	           => $row['hair']
		       	   	  );
       	  if(!empty(array_filter($examination)) && !empty($examinationswitch)){      	  	          
                      $examination_per=count(array_filter($examination));
                      $examination=json_encode($examination);
                      $examination_notes=$row['examination_notes'];  
       	  	      }
       	  	      else {
       	  	      	$examination='';
       	  	      	$examination_per='';

       	  	      }
          if(strtolower($row['stage'])=='child')$stage='C'; else  if(strtolower($row['stage'])=='adult')$stage='A'; else $stage='';
         
         if($row['alignment']=='Normal')$align='N';
		          else if($row['alignment']=='Abnormal')$align='ABN';
				  else $align='';
         $dental=$dental_arr=array(
       	   	      "gum_info"   	       => $this->replace_p_ab($row['gum_info']),
       	   	      "sensitivity"  	   => $this->replace_p_ab($row['sensitivity']),
       	   	      "bleeding"		   => $this->replace_p_ab($row['bleeding']),
       	   	      "filling"  		   => $this->replace_p_ab($row['filling']),
       	   	      "caries"		       => $this->replace_p_ab($row['caries']),
       	   	      "alignment"          => $align,
       	   	      "bad_odor"		   => $this->replace_p_ab($row['bad_odor']),
       	   	      "plaque"	           => $this->replace_p_ab($row['plaque']),
       	   	      "stage"		       => $stage,       	   	      
       	   	  );

        if(!empty(array_filter($dental))&& !empty($dentalswitch)){        	        
                    $dental_per=count(array_filter($dental))-1;
                    $dental=json_encode($dental);
                    $dental_notes=$row['dental_notes'];  

        	    }
        	    else {
        	    	$dental='';
        	    	$dental_per='';
        	    }

        $f = new NumberFormatter("en", NumberFormatter::SPELLOUT); 
        if(!empty($row['scal'])){
        	 $a=explode(',',$row['scal']);
             $scal=array();
                 
	        	 foreach($a as $s){
	        	 	$val = $f->format($s);
	                $scal[$val]=$s;
	        	 }
	        	 $scal=json_encode($scal);
          }else $scal='';         
                              
 
     $final_notes=$this->evaluate_final_notes($general_arr,$eye_arr,$dental_arr,$ent_arr,$cardiovascular_arr,$examination_arr);

        $data=array(
                  "general"   	      => $general,
       	   	      "ent"  	          => $ent,
       	   	      "dental"		      => $dental,
       	   	      "cardiovascular"    => $cardiovascular,
       	   	      "examination"		  => $examination,
       	   	      "eye"               => $eye,

       	   	      "generalswitch"   	    => $generalswitch,
       	   	      "entswitch"  	            => $entswitch,
       	   	      "dentalswitch"		    => $dentalswitch,
       	   	      "cardiovascularswitch"    => $cardiovascularswitch,
       	   	      "examinationswitch"		=> $examinationswitch,
       	   	      "eyeswitch"               => $eyeswitch,

       	   	      "general_notes"   	    => $general_notes,
       	   	      "ent_notes"  	            => $ent_notes,
       	   	      "dental_notes"		    => $dental_notes,
       	   	      "cardiovascular_notes"    => $cardiovascular_notes,
       	   	      "examination_notes"		=> $examination_notes,
       	   	      "eye_notes"               => $eye_notes,       	   	    

       	   	      "eye_per"                 => $eye_per,
				  "ent_per"                 => $ent_per,
				  "dental_per"              => $dental_per,
				  "cardiovascular_per"      => $cardiovascular_per,
				  "examination_per"         => $examination_per,
				  "general_per"             => $general_per,

       	   	      "scal"                    => $scal,
				  "doctors_id"              => $doctor_id,
       	   	     //"student_id"             => $row['student_id'],
				  "final_notes"             => $final_notes,
       	   	     

        );

     
  	if(!empty(array_filter($data))){

     $res = $this->common_model->get_row('student_test',array('student_id'=>$row['student_id'],'test_id'=>$test_id));
       if(!empty($res)){ 
		   if(!empty($res->upload_file))$data['dental_per']=$dental_per+1;
          $this->common_model->update('student_test',$data,array('student_id'=>$row['student_id']));
       }else{
       
       		$data['student_id'] = $row['student_id']; 
       		$data['test_id']    = $test_id;     
       		$stud = $this->common_model->get_row('student',array('student_id'=>$row['student_id']),array('class','roll_no','division'));
       		if(!empty($stud)){
       			$data['class_id'] = $stud->class; 
       			$data['division'] = $stud->division; 
       			$data['roll_no']  = $stud->roll_no; 
       		}
       		$this->common_model->insert('student_test',$data);
       
       }	   
       	   //p($data);
       } 
       //break;
   }
   unlink($filepath);
    $this->session->set_flashdata('msg_success', 'Student Information uploaded successfully.');
	redirect($_SERVER['HTTP_REFERER']);
}


function importDemoCSV(){
	// ini_set('memory_limit', '-1');
        $this->_check_login();
		date_default_timezone_set('Asia/Kolkata');
    	$doctor_id =  $this->input->post('doctor_id');
		$school_id =  $this->input->post('school_id');
		$test_id   =  $this->input->post('test_id');
	
    	$config['upload_path']   = './assets/uploads/imports';
        $config['allowed_types'] = 'xls';
        $config['max_size']      = '10000';
        $this->load->library('upload', $config);
        $this->load->library('csvimport');
        $this->upload->initialize($config);
        //read file from path
        if (!$this->upload->do_upload('import_csv')) {
            // $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('msg_error', 'Not Uploaded or Incorrect Format');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $file_data = $this->upload->data();
             $this->load->library('excel');
            $file_path = 'assets/uploads/imports/' . $file_data['file_name'];

            $excelReader = PHPExcel_IOFactory::createReaderForFile($file_path);
            $excelObj    = $excelReader->load($file_path);
            $worksheet   = $excelObj->getSheet(0);
            $lastRow     = $worksheet->getHighestRow();
            $array       =   $excelObj->getActiveSheet()->toArray(null,true,true,true);
            
            // p($array);
            $loadedSheetNames = $excelObj->getSheetNames();

            $objWriter = PHPExcel_IOFactory::createWriter($excelObj, 'CSV');

            foreach($loadedSheetNames as $sheetIndex => $loadedSheetName) {
              $objWriter->setSheetIndex($sheetIndex);
              $objWriter->save('assets/uploads/imports/demo.csv');
            }
            @unlink($file_path);
            $file_path='assets/uploads/imports/demo.csv';
           
            $this->readExcel($file_path,$doctor_id,$school_id,$test_id);
          
        }               

}

function get_all_directory_and_files($dir){
 
     $dh = new DirectoryIterator($dir);   
     // Dirctary object 
     foreach ($dh as $item) {
         if (!$item->isDot()) {
            if ($item->isDir()) {
                $this->get_all_directory_and_files("$dir/$item");
            } else {
                //echo $dir . "/" . $item->getFilename();
                //echo "<br>";

                   $a=explode('/',$dir);
				   $student_id=$a[count($a)-1];
				   $image=$item->getFilename();
				   $ext= pathinfo($image, PATHINFO_EXTENSION);
				   $new_name=$this->salt().'.'.$ext;

				   $row=$this->common_model->get_row('student_test',array('student_id'=>$student_id,'test_id'=>$this->input->get('test_id')),array('upload_file'));

				   if(!empty($row)){ 
				   	     $upload=$row->upload_file;
				   	     if(!empty($upload))$upload=json_decode($upload);else $upload=array();
				   	     array_unshift($upload,$new_name);
						 if(count($upload)>2){
							 unlink('assets/uploads/files/'.$upload[2]);
							 unset($upload[2]);
						 }
				   	     $data=array('upload_file'=>json_encode($upload));
				   	      copy($dir . "/" . $item->getFilename(),'assets/uploads/files/'.$new_name);
                          unlink($dir . "/" . $item->getFilename());
						  //unlink($dir);
				   	     $this->common_model->update('student_test',$data,array('student_id'=>$student_id));
				   	     $this->session->set_userdata('uploaded','yes');
						 
						 //delete folder
						 
				   }
                
            }
         }
      }
   }

function scy_student_images($school_id=''){
	if(empty($this->input->get('test_id'))){
			$this->session->set_flashdata('msg_error','Sorry! Test id is invalid, Please try again');
	  		redirect($_SERVER['HTTP_REFERER']);
	  }

	 $this->get_all_directory_and_files("upload");
	 if($this->session->userdata('uploaded')=='yes'){
		  $this->delete_all_directory("upload");
		  
	      $this->session->set_flashdata('msg_success', 'Images uploaded successfully');
        }
        else{
        	$this->session->set_flashdata('msg_error', 'Some error is coming');
        }
       redirect($_SERVER['HTTP_REFERER']);

}
function delete_all_directory($path){
    $dir_list = glob( $path . '/*', GLOB_ONLYDIR );
    foreach($dir_list as $dir){
		//p(glob( $dir.'/*' )).'<br>';
		if(empty(glob( $dir.'/*' ))){
			rmdir($dir); // if file  deleted only
		}
      }
}

function replace_p_ab($a){
	$a=str_ireplace('Present','P',$a);
	$a=str_ireplace('Absent','AB',$a);
	return $a;
}
function replace_p_ab_op($a){
	$a=str_ireplace('P','Present',$a);
	$a=str_ireplace('AB','Absent',$a);
	return $a;
}  
 function replace_p_b($a){
	$a=str_ireplace('good','Good',$a);
	$a=str_ireplace('bad','Bad',$a);
	$a=str_ireplace('na','N/A',$a);
	return $a;
} 
function replace_p_b_op($a){
	$a=str_ireplace('Good','good',$a);
	$a=str_ireplace('Bad','bad',$a);
	$a=str_ireplace('N/A','na',$a);
	return $a;
} 
function evaluate_final_notes($general,$eye,$dental,$ent,$cardiovascular,$examination){
      $i=0;
      $general   =(object)$general;
      $eye       =(object)$eye;
      $ent       =(object)$ent;
      $cardiovascular=(object)$cardiovascular;
      $examination=(object)$examination;



    		   $final_notes = "";
    			if (!empty($general)){
                    if(!empty($row['bmi_status']) && $row['bmi_status'] != 'Normal'){
                    $i=1;
                    $final_notes .=  'BMI percentile status is ' .$row['bmi_status'].'.';
                    }
                }
                if (!empty($eye)){    
                    if(!empty($eye->myopia) && $eye->myopia == 'P'){
                     $i=1;
                    $final_notes .=  'Myopia is present.';
                    }

                    if(!empty($eye->hyperopia) && $eye->hyperopia == 'P'){
                     $i=1;
                    $final_notes .=  'Hyperopia is present.';
                    }

                    if(!empty($eye->astigmatism) && $eye->astigmatism == 'P'){
                      $i=1;
                    $final_notes .=  'Astigmatism is present.';
                    }

                    if(!empty($eye->anisometropia) && $eye->anisometropia == 'P'){
                      $i=1;
                    $final_notes .=  'Anisometropia is present.';
                    }

                    if(!empty($eye->strabismus) && $eye->strabismus == 'P'){
                     $i=1;
                    $final_notes .=  'Strabismus is present.';
                    }

                    if(!empty($eye->anisocoria) && $eye->anisocoria == 'P'){
                     $i=1;
                    $final_notes .=  'Anisocoria is present.';
                    }

                    if(!empty($eye->screeing_result) && $eye->screeing_result == 'Refer'){
                    	 $i=1;
                    	$final_notes .=  'Abnormal vision identified.';
                    	}

                }
                if (!empty($dental)){      

                    if(!empty($dental->gum_info) && $dental->gum_info == 'P'){
                     $i=1;
                    $final_notes .=  'Gum Inflammation was found.';
                    }

                    if(!empty($dental->sensitivity) && $dental->sensitivity == 'P'){
                     $i=1;
                    $final_notes .=  'Sensitivity was found.';
                    }

                    if(!empty($dental->bleeding) && $dental->bleeding == 'P'){
                     $i=1;
                    $final_notes .=  'Bleeding was found.';
                    }

                    if(!empty($dental->filling) && $dental->filling == 'P'){
                    $i=1;
                    $final_notes .=  'Filling In Teeth was found.';
                    }

                    if(!empty($dental->caries) && $dental->caries == 'P'){
                     $i=1;
                    $final_notes .=  'Caries was found.';
                    }

                    if(!empty($dental->bad_odor) && $dental->bad_odor == 'P'){
                       $i=1;             
                    $final_notes .=  'Bad Odour was found.';
                    }

                    if(!empty($dental->plaque) && $dental->plaque == 'P'){
                      $i=1;  
                    $final_notes .=  'Plaque was found.';

                    }

                    if(!empty($dental->alignment) && $dental->alignment == 'ABN'){
                     $i=1;
                    $final_notes .=  'Alignment Of Teeth is abnormal.';

                    }
                }

                if (!empty($ent)){
                    if(!empty($ent->ear_wax) && $ent->ear_wax == 'Present'){
                     $i=1;
                    $final_notes .=  'Ear wax is present.';
                    }

                    if(!empty($ent->tonsils) && $ent->tonsils == 'Present'){
                     $i=1;
                    $final_notes .=  'Tonsils is present.';
                    }

                    if(!empty($ent->nosal_track) && $ent->nosal_track == 'Abnormal'){
                     $i=1;
                    $final_notes .=  'Nasal Track is abnormal.';

                    }
                                      
                    if(!empty($ent->ear_drum) && $ent->ear_drum == 'Abnormal'){
                     $i=1;
                    $final_notes .=  'Drum is abnormal.';

                    }
                }
		        if (!empty($cardiovascular)){
		                
					if(!empty($cardiovascular->mummur) && $cardiovascular->mummur == 'Abnormal'){
		                 $i=1;
		                $final_notes .=  'Heart Sound is abnormal.';

		                }
		                
		            if(!empty($cardiovascular->pulse_status) && $cardiovascular->pulse_status == 'bad'){
		                 $i=1;
		                $final_notes .=  'Pulse rate is abnormal.';

		                }
		           
		            if(!empty($cardiovascular->resporatory_status) && $cardiovascular->resporatory_status == 'bad'){
		                  $i=1;
		                $final_notes .=  'Respiratory rate is abnormal.';

		                }
					if(!empty($cardiovascular->oximetry_status) && $cardiovascular->oximetry_status == 'bad'){
				            $i=1;
				            $final_notes .=  'Saturated oxygen level is abnormal.';
							}
					if(!empty($cardiovascular->auscultation) && $cardiovascular->auscultation == 'Abnormal'){
									  $i=1; 
									$final_notes .=  'Lung sound is abnormal.';
								}

					if(!empty($cardiovascular->spirometry_status) && $cardiovascular->spirometry_status =='bad'){
							 $i=1;
							$final_notes .=  'Lung Capacity is abnormal.';

							}
				}

                if (!empty($examination)){    
                    if(!empty($examination->hair) && $examination->hair == 'Bad'){
                     $i=1;
                    $final_notes .=  'Hair Hygiene is not good.';
                    }
                if(!empty($examination->nail) && $examination->nail == 'Bad'){
                     $i=1;
                    $final_notes .=  'Nail Hygiene is not good.';
                    }

                if(!empty($examination->palor) && $examination->palor == 'Present'){
                     $i=1;
                    $final_notes .=  'Palor is present.';
                    }

                if(!empty($examination->lymphadenopathy) && $examination->lymphadenopathy == 'Present'){
                     $i=1;
                    $final_notes .=  'Lymphadenopathy is present.';
                    }
                if(!empty($examination->edema) && $examination->edema == 'Present'){
                     $i=1;
                    $final_notes .=  'Edema is present.';
                    }

                if(!empty($examination->cyanosis) && $examination->cyanosis == 'Present'){
                     $i=1;
                    $final_notes .=  'Cyanosis is present.';
                    }

                if(!empty($examination->icterus) && $examination->icterus == 'Present'){
                     $i=1;
                    $final_notes .=  'Icterus is present.';
                    }

                if(!empty($examination->allergy) && $examination->allergy == 'Present'){
                     $i=1;
                    $final_notes .=  'Allergy is present.';
                    }  

                if(!empty($examination->stomach_ache) && $examination->stomach_ache == 'Present'){
                     $i=1;
                    $final_notes .=  'Stomach Ache is present.';
                    }

                if(!empty($examination->skin) && $examination->skin == 'Abnormal'){
                     $i=1;
                    $final_notes .=  'Skin is abnormal.';
                    } 

                if(!empty($examination->cns) && $examination->cns == 'Abnormal'){
                     $i=1; 
                    $final_notes .=  'CNS Parameter is abnormal.';
                    } 
                    
            } 

              
              if($i==0){

              	$final_note='All test results seem normal.'.$final_notes;
              }
              else {
              	 $final_note='All test results seem normal, Except the following :<br>'.$final_notes;
              }

				return $final_notes= str_replace(".",".<br>",$final_note);
}


function delete_test_report(){
	  $where=array(
	  	   'student_id'=>$this->input->post('id'),
	  	   'test_id'=> $this->input->post('test_id')
	  	);

      if($this->common_model->update('student_test',array('is_delete'=>1),$where)){
      	 $this->session->set_flashdata('msg_success','Test Report deleted successfully.');  	
      }else{
      	 $this->session->set_flashdata('msg_error','Test Report not added.');  
      }
       redirect($_SERVER['HTTP_REFERER']);
}


function update_deactive_students($school_id,$test_id='',$student_id){
        if(!empty($test_id)){
        	$result=$this->common_model->get_result('deactive_students',array('school_id'=>$school_id,'test_id!='=>$test_id));
        }else{
        	$result=$this->common_model->get_result('deactive_students',array('school_id'=>$school_id));
        }
		
				
				if(!empty($result)){
					foreach($result as $res){
					$deactive=$res->deactive_student_ids;
					   if(empty($deactive))$deactive_student_ids=$student_id;
					     else $deactive_student_ids=$deactive.','.$student_id;
			
                    $data=array('deactive_student_ids'=>$deactive_student_ids);
				    $this->db->where(array('school_id'=>$school_id,'test_id'=>$res->test_id));
                    $this->common_model->update('deactive_students',$data);
                   
                  }
                }
}
function add_deactive_student($school_id,$test_id){
         $student_id = $this->input->post('student_id');	
		$result = $this->common_model->get_row('deactive_students',array('school_id'=>$school_id,'test_id'=>$test_id));
		
		if(!empty($result)){
			$ids=explode(',',$result->deactive_student_ids);
			if (($key = array_search($student_id, $ids)) !== false) {
				unset($ids[$key]);
			}
			$ids=implode(',',$ids);
			$data=array('deactive_student_ids'=>$ids);
			if($this->common_model->update('deactive_students',$data,array('school_id'=>$school_id,'test_id'=>$test_id))){
				 $this->session->set_flashdata('msg_success','Student Added successfully.'); 
			}else{
				$this->session->set_flashdata('msg_error','Student not added'); 
			}
		}
		
       redirect($_SERVER['HTTP_REFERER']);
		
	
	
	
}


public function change_all_status_of_test(){
      //$this->_check_login(); //check login authentication

     
    
      $row_ids=$this->input->post('row_id');
      $col_name=$this->input->post('col_name');
      $school_id=$this->input->post('school_id');
	  $status=$this->input->post('status');
      $test_id=$this->input->post('test_id');
     //$status=1; $row_ids=array(5784,5785);$test_id=39;$school_id=159;

      $result = $this->common_model->get_row('deactive_students',array('school_id'=>$school_id,'test_id'=>$test_id));
		
		if(!empty($result)){
			if(!empty($result->deactive_student_ids))
			        $ids=explode(',',$result->deactive_student_ids);
			else $ids=array();  

			if($status==1){
				foreach($row_ids as $r){
					if(($key = array_search($r, $ids)) !== false) {
					   unset($ids[$key]);
				    }
			   }
			}else if($status==0){
				foreach($row_ids as $r){
				     $ids[]=$r;
			    }
			}
			
			if(!empty($ids))
			      $ids=implode(',',$ids);
			else $ids=NULL; 

			$data=array('deactive_student_ids'=>$ids);
			if($this->common_model->update('deactive_students',$data,array('school_id'=>$school_id,'test_id'=>$test_id))){
				 $this->session->set_flashdata('msg_success','Student Test Status updated successfully.'); 
			}else{
				$this->session->set_flashdata('msg_error','Student Test Status not updated'); 
			}
		}


    
      
    redirect($_SERVER['HTTP_REFERER']);
    } 


function reject11(){
	$query=$this->db->query("select student_id,class,division,roll_no,school_id from student where school_id=119");
$result = $query->result();

foreach($result as $row){
$data=array(
    'class_id'=>$row->class,
    'division'=>$row->division,
    'roll_no'=>$row->roll_no,
    'test_id'=>5
   );
   $this->db->where('student_id',$row->student_id);
$this->db->update('student_test',$data);

}
   
}


}




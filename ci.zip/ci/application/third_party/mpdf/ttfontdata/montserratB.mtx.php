<?php
$name='Montserrat-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 968.0,
  'Descent' => -251.0,
  'CapHeight' => 699.0,
  'Flags' => 262148,
  'FontBBox' => '[-111 -250 1083 948]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 264.0,
);
$up=-75;
$ut=50;
$ttffile='D:/wamp64/www/ehr/application/third_party/mpdf/ttfonts/Montserrat-Bold.ttf';
$TTCfontID='0';
$originalsize=29560;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='montserratB';
$panose=' 0 0 2 0 5 5 0 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>
<?php
$name='DejaVuSerif';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-770 -347 1679 1242]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='D:/wamp64/www/ehr/application/third_party/mpdf/ttfonts/DejaVuSerif.ttf';
$TTCfontID='0';
$originalsize=330052;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserif';
$panose=' 0 0 2 6 6 3 5 6 5 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>
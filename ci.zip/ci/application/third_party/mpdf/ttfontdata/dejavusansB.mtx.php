<?php
$name='DejaVuSans-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262148,
  'FontBBox' => '[-1069 -415 1975 1174]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='D:/wamp64/www/ehr/application/third_party/mpdf/ttfonts/DejaVuSans-Bold.ttf';
$TTCfontID='0';
$originalsize=584396;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansB';
$panose=' 0 0 2 b 8 3 3 6 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>
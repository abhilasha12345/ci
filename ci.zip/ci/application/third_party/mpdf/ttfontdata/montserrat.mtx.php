<?php
$name='Montserrat-Regular';
$type='TTF';
$desc=array (
  'Ascent' => 968.0,
  'Descent' => -251.0,
  'CapHeight' => 699.0,
  'Flags' => 4,
  'FontBBox' => '[-110 -250 1130 932]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 274.0,
);
$up=-75;
$ut=50;
$ttffile='D:/wamp64/www/ehr/application/third_party/mpdf/ttfonts/Montserrat-Regular.ttf';
$TTCfontID='0';
$originalsize=29016;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='montserrat';
$panose=' 0 0 2 0 5 5 0 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>
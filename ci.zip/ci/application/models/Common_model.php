<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends CI_Model {	

	public function insert($table_name='',  $data=''){
		$query=$this->db->insert($table_name, $data);
		if($query)
			return $this->db->insert_id();
		else
			return FALSE;		
	}
	public function get_result($table_name='', $id_array='',$columns=array(),$order_by=array(),$limit=''){
		if(!empty($columns)):
			$all_columns = implode(",", $columns);
			$this->db->select($all_columns);
		endif;
		if(!empty($order_by)):			
			$this->db->order_by($order_by[0], $order_by[1]);
		endif; 
		if(!empty($id_array)):		
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			}
		endif;	
		if(!empty($limit)):	
			$this->db->limit($limit);
		endif;	
		$query=$this->db->get($table_name);
		if($query->num_rows()>0)
			return $query->result();
		else
			return FALSE;
	}
	public function get_row($table_name='', $id_array='',$columns=array(),$order_by=array()){
		
		if(!empty($columns)):
			$all_columns = implode(",", $columns);
			$this->db->select($all_columns);
		endif; 
		if(!empty($id_array)):		
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			}
		endif;
		if(!empty($order_by)):			
			$this->db->order_by($order_by[0], $order_by[1]);
		endif; 
		$query=$this->db->get($table_name);
		if($query->num_rows()>0)
			return $query->row();
		else
			return FALSE;
	}

	public function update($table_name='', $data='', $id_array=''){
		if(!empty($id_array)):
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			}
		endif;
		return $this->db->update($table_name, $data);		
	}

	public function delete($table_name='', $id_array=''){		
	 return $this->db->delete($table_name, $id_array);
	}


	public function login($email,$password){	
	
		$data  = array('email'=>$email);	
		$query_get = $this->db->get_where('users',$data);
		$count = $query_get->num_rows();
		$res = $query_get->row_array();
		if(empty($res))
		{
			$data  = array('code'=>$email);	
			$query_get = $this->db->get_where('users',$data);
			$count = $query_get->num_rows();
			$res = $query_get->row_array();
		}

		if($count==1){
			$salt = $res['salt'];
			$user_type = $res['user_role'];
			if($user_type=='1'){
				$ur = 1;
			}else if($user_type=='2'){
				$code = $res['code'];
				$ur = 2;
			}else if($user_type=='3'){
				$ur = 3;
			}
			if($ur==2)
				$query = "SELECT * FROM `users` WHERE `code` ='".$code."' AND `password` = '".sha1($salt.sha1($salt.sha1($password)))."' AND `user_role` = '".$ur."'";
			else
				$query = "SELECT * FROM `users` WHERE `email` ='".$email."' AND `password` = '".sha1($salt.sha1($salt.sha1($password)))."' AND `user_role` = '".$ur."'";
			
			$sql= $this->db->query($query);
			$check_count = $sql->num_rows();
			$result = $sql->row();

          	if($check_count == 1)
			{
				//p('fdsFD'); die;
				if($result->status==1){

					$user_data = array(
						'id' 			=> $sql->row()->user_id,
						'user_role' 	=> $sql->row()->user_role,
						'email'			=> $sql->row()->email,
						'full_name' 	=> $sql->row()->full_name,
						'logged_in' 	=> TRUE
					);

					if($user_type=='1'){
						$this->session->unset_userdata('superadmin_info');
						$this->session->set_userdata('superadmin_info',$user_data);
					}else if($user_type=='2'){
						$this->session->unset_userdata('doctor_info');
						$this->session->set_userdata('doctor_info',$user_data);
					}else if($user_type=='3'){
						$this->session->unset_userdata('school_info');
						$this->session->set_userdata('school_info',$user_data);
					}

					$this->update('users',array('last_ip' => $this->input->ip_address(),
							'last_login' => date('Y-m-d h:i:s')),array('user_id'=>$sql->row()->user_id));
					return TRUE;

				}else{
					$this->session->set_flashdata('msg_error', 'Your account is not activated yet. Please contact to administrator');
					return FALSE;
				}
				
			}else{
				$this->session->set_flashdata('msg_error', 'Incorrect Email Or Password');
				return FALSE;
			}	
		}else{
			$this->session->set_flashdata('msg_error', 'Incorrect Email Or Password');
			return FALSE;
		}
	}

	public function password_check($data=''){  
		$query = $this->db->get_where('users',$data);
 		if($query->num_rows()>0)
			return TRUE;
		else{
			return FALSE;
		}
	}


		public function proxy_login($data=array()){	

		$query_get = $this->db->get_where('users',$data);
		$count = $query_get->num_rows();
		$res = $query_get->row_array();

		$status = $res['status'];
		$user_role = $res['user_role'];

		if($count==1){
			
				$user_data = array(
					'id' 				=> $res['user_id'],
					'user_role' 		=> $res['user_role'],
					'email'				=> $res['email'],
					'full_name' 		=> $res['full_name'],
					'logged_in' 		=> TRUE
				);
				$this->update('users',array('last_ip' => $this->input->ip_address(),
							'last_login' => date('Y-m-d h:i:s')),array('user_id'=>$res['user_id']));
				return $user_data;
			
		}else{
			return FALSE;
		}
	}



	
}